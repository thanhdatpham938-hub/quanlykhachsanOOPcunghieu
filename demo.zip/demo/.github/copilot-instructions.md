# Copilot instructions for HotelBookingSystem

This file gives concise, actionable guidance to AI coding assistants working on this repository.

- **Project type:** C# (.NET 8) Windows Forms application and console helpers. Main project is `HotelBookingSystem/HotelBookingSystem.csproj` and solution `demo.sln`.
- **Entry point:** `Program.cs` (creates UI / console glue). Primary controller: `Controllers/HeThongQuanLy.cs`.

- **High-level architecture:**
  - `Models/` contains domain types: `NguoiDung` (abstract base), `DerivedUsers.cs` (KhachHang, NhanVien, QuanLy), `Phong.cs`, `Enums.cs`, and booking model `DonDatPhong`.
  - `Controllers/HeThongQuanLy.cs` coordinates user actions, room management and bookings. It holds in-memory lists: `cacNguoiDung`, `cacPhong`, `cacDonDat` and initializes sample data in `KhoiTaoDuLieuMau()`.
  - `UI/` contains WinForms screens (`Form*.cs`) and `GiaoDienConsole.cs` for a console interface.
  - `Exceptions/HotelExceptions.cs` defines custom exceptions used across business logic. Prefer reusing them when adding new validation.

- **Build & run (developer workflow):**
  - Requires .NET 8 and Windows for WinForms UI.
  - Build entire solution: `dotnet build demo.sln` (run from repo root).
  - Build/run project: `dotnet build HotelBookingSystem/HotelBookingSystem.csproj` or `dotnet run --project HotelBookingSystem/HotelBookingSystem.csproj`.
  - Prefer using Visual Studio for debugging WinForms; CLI run opens the WinForms window on Windows.

- **Conventions & important patterns:**
  - Code uses Vietnamese identifiers (e.g., `NguoiDung`, `Phong`, `DonDatPhong`). Search these exact names when tracing logic.
  - Role checks are explicit (type or enum): `nguoiDungDangNhap is KhachHang` / `VaiTro == VaiTro.NhanVien`.
  - Controller methods print to console and also modify model lists; UI forms call controller methods instead of duplicating logic.
  - Sample data and test accounts are created in `HeThongQuanLy.KhoiTaoDuLieuMau()` — useful for quick manual testing (accounts: `0123456789/admin123`, `0987654321/staff123`, `0911111111/customer123`).
  - Use provided custom exceptions (e.g., `InvalidLoginException`, `DuplicateIdException`, `RoomUnavailableException`) to keep error handling consistent.
  - Avoid modifying generated WinForms designer files (`*.Designer.cs`) — change logic in the code-behind (`Form*.cs`) or controller.

- **Where to change business logic:**
  - Add/modify booking, room or user logic inside `Controllers/HeThongQuanLy.cs` and `Models/*` classes. The UI should remain a thin view layer that calls the controller.

- **Quick code examples (search patterns):**
  - Find logged-in user usage: `nguoiDungDangNhap` in `HeThongQuanLy.cs`.
  - Find room availability logic: `Phong.KiemTraPhongTrong(checkIn, checkOut, cacDonDat)` in `HeThongQuanLy.cs` and `Phong.cs`.
  - Look for exception definitions in `Exceptions/HotelExceptions.cs` and usage across controller methods.

- **Testing / Limitations:**
  - No unit tests present. Manual testing is supported via the UI and sample data.
  - Data is stored in-memory; persistence is not implemented. Changes will be lost when the app exits.

- **Editing & PR guidance for contributors/agents:**
  - Keep messages and variable names in Vietnamese where consistent with existing code.
  - When adding new exceptions, add them to `Exceptions/HotelExceptions.cs` and use the same pattern of catch-and-Console.Write in controller methods.
  - If adding persistence, implement it behind `HeThongQuanLy` (e.g., a repository interface) to limit UI changes.

If anything here is unclear or you want more details (examples for a specific file, or a guide for adding persistence or tests), tell me and I'll expand this file.
