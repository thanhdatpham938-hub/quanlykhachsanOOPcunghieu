# ✅ HỆ THỐNG QUẢN LÝ ĐẶT PHÒNG KHÁCH SẠN - HOÀN THÀNH

## 📦 Thành Phần Dự Án

### 1. **Cấu Trúc Thư Mục**

```
HotelBookingSystem/
│
├── Models/                          # Lớp mô hình dữ liệu
│   ├── Enums.cs                    # Enum: VaiTro, TrangThaiPhong, TrangThaiDon
│   ├── NguoiDung.cs                # Base class (abstract)
│   ├── DerivedUsers.cs             # KhachHang, NhanVien, QuanLy
│   └── Phong.cs                    # Phong, DonDatPhong
│
├── Controllers/                     # Logic xử lý chính
│   └── HeThongQuanLy.cs            # Điều khiển toàn bộ hệ thống
│
├── Exceptions/                      # Xử lý ngoại lệ
│   └── HotelExceptions.cs          # 7 custom exceptions
│
├── UI/                              # Giao diện người dùng
│   └── GiaoDienConsole.cs          # Console menu
│
├── Program.cs                       # Điểm vào chương trình
├── HotelBookingSystem.csproj        # File cấu hình project
│
├── README.md                        # Tài liệu chính
├── QUICK_START.md                   # Bắt đầu nhanh
├── HUONG_DAN_CHI_TIET.md           # Hướng dẫn chi tiết
├── KIEN_TRUC_HE_THONG.md           # Kiến trúc & thiết kế
├── TONG_KET.md                      # Tóm tắt dự án
│
└── .gitignore                       # Git ignore patterns
```

## 🎯 Các Lớp Chính (7 Classes)

### **1. NguoiDung (Abstract Base Class)**
```csharp
public abstract class NguoiDung
{
    public string HoTen { get; set; }
    public string SoDienThoai { get; set; }  // Primary Key
    public string MatKhau { get; set; }
    public VaiTro VaiTro { get; set; }
    public TrangThaiTaiKhoan TrangThaiTaiKhoan { get; set; }
    
    public virtual bool DangNhap(string sdt, string pass);
    public virtual void DangXuat();
    public virtual void DoiMatKhau(string cu, string moi);
    public virtual void HienThiThongTin();
}
```

### **2. KhachHang (Derived)**
```csharp
public class KhachHang : NguoiDung
{
    public List<DonDatPhong> LichSuGiaoDich { get; set; }
    
    public void DatPhongOnline(DonDatPhong don);
    public bool HuyDatPhong(string maDon);
    public void XemLichSu();
    public void XoaTaiKhoan();
}
```

### **3. NhanVien (Derived)**
```csharp
public class NhanVien : NguoiDung
{
    public DonDatPhong DatPhongOffline(
        string tenKhach, string sdtKhach,
        Phong phong, DateTime checkIn, DateTime checkOut);
}
```

### **4. QuanLy (Derived)**
```csharp
public class QuanLy : NguoiDung
{
    public Phong ThemPhong(string maPhong, LoaiPhong loai, decimal gia);
    public void SuaPhong(Phong phong, LoaiPhong? loai, decimal? gia);
    public void XoaPhong(Phong phong, List<DonDatPhong> donDat);
    public NhanVien ThemNhanVien(string hoTen, string sdt, string pass);
    public void XemBaoCaoDoanhThu(List<DonDatPhong> donDat, int thang, int nam);
}
```

### **5. Phong (Room)**
```csharp
public class Phong
{
    public string MaPhong { get; set; }
    public LoaiPhong LoaiPhong { get; set; }
    public decimal GiaTien { get; set; }
    public TrangThaiPhong TrangThaiHienTai { get; set; }
    
    public bool KiemTraPhongTrong(DateTime checkIn, DateTime checkOut, 
                                  List<DonDatPhong> donDat);
    public void HienThiThongTin();
}
```

### **6. DonDatPhong (Booking)**
```csharp
public class DonDatPhong
{
    public string MaDon { get; set; }
    public KhachHang? KhachHang { get; set; }
    public string? TenKhachVangLai { get; set; }
    public string? SdtKhachVangLai { get; set; }
    public Phong? Phong { get; set; }
    public DateTime NgayCheckIn { get; set; }
    public DateTime NgayCheckOut { get; set; }
    public decimal TongTien { get; set; }
    public TrangThaiDon TrangThaiDon { get; set; }
    
    public void TinhTongTien();
    public void HienThiThongTin();
}
```

### **7. HeThongQuanLy (System Manager)**
```csharp
public class HeThongQuanLy
{
    private List<NguoiDung> cacNguoiDung;
    private List<Phong> cacPhong;
    private List<DonDatPhong> cacDonDat;
    private NguoiDung? nguoiDungDangNhap;
    
    // 40+ methods cho tất cả chức năng hệ thống
    public void DangNhap(string sdt, string pass);
    public void DangKy(string hoTen, string sdt, string pass);
    public void DatPhongOnline(DateTime checkIn, DateTime checkOut, string maPhong);
    public void DatPhongOffline(string tenKhach, string sdt, string maPhong, 
                                DateTime checkIn, DateTime checkOut);
    // ... và nhiều phương thức khác
}
```

## 📊 Enum Types (5)

```csharp
enum VaiTro { KhachHang, NhanVien, QuanLy }
enum TrangThaiPhong { SanSang, DangBaoTri }
enum TrangThaiDon { DaDat, DaHuy, DaHoanThanh }
enum LoaiPhong { Don, Doi, VIP }
enum TrangThaiTaiKhoan { HoatDong, VoHieuHoa }
```

## 🛡️ Exception Classes (7)

| Exception | Mô Tả |
|-----------|-------|
| `InvalidLoginException` | Sai SĐT hoặc mật khẩu |
| `DuplicateIdException` | SĐT/ID đã tồn tại |
| `RoomUnavailableException` | Phòng không trống |
| `DataConstraintException` | Vi phạm ràng buộc |
| `InvalidDataException` | Dữ liệu không hợp lệ |
| `InvalidDateException` | Ngày không hợp lệ |
| `ResourceNotFoundException` | Không tìm thấy |

## 🎨 OOP Concepts Áp Dụng

### ✅ Inheritance (Kế Thừa)
```
NguoiDung (Base)
├── KhachHang
├── NhanVien
└── QuanLy
```

### ✅ Polymorphism (Đa Hình)
```csharp
// Override method
public override void HienThiThongTin()
{
    base.HienThiThongTin();
    // Logic riêng cho mỗi lớp con
}
```

### ✅ Encapsulation (Đóng Gói)
```csharp
// Properties với getters/setters
public string HoTen { get; set; }

// Validation trong constructor
if (string.IsNullOrWhiteSpace(matKhau) || matKhau.Length < 6)
    throw new InvalidDataException("Mật khẩu quá ngắn!");
```

### ✅ Abstraction (Trừu Tượng)
```csharp
public abstract class NguoiDung
{
    public virtual bool DangNhap(string sdt, string pass);
    public virtual void HienThiThongTin();
}
```

### ✅ Composition (Bao Gồm)
```csharp
// HeThongQuanLy quản lý
public List<NguoiDung> cacNguoiDung;
public List<Phong> cacPhong;
public List<DonDatPhong> cacDonDat;
```

## 🚀 Build & Run

```bash
# Build project
dotnet build

# Run application
dotnet run

# Output:
# Build succeeded.
# 0 Warning(s)
# 0 Error(s)
# 
# ╔══════════════════════════════════════╗
# ║ HỆ THỐNG QUẢN LÝ ĐẶT PHÒNG KHÁCH SẠN ║
# ╚══════════════════════════════════════╝
```

## 📋 Danh Sách Chức Năng (20+ Features)

### 👤 Xác Thực
- ✓ Đăng Ký (chỉ khách hàng)
- ✓ Đăng Nhập (tất cả vai trò)
- ✓ Đăng Xuất
- ✓ Thay đổi mật khẩu

### 🏨 Quản Lý Phòng (Quản Lý)
- ✓ Thêm phòng
- ✓ Sửa thông tin phòng
- ✓ Xóa phòng (với kiểm tra ràng buộc)
- ✓ Xem danh sách phòng

### 📅 Đặt Phòng
- ✓ Đặt phòng online (Khách Hàng)
- ✓ Đặt phòng offline (Nhân Viên)
- ✓ Hủy phòng (Khách Hàng - 24h trước)
- ✓ Tìm phòng trống theo khoảng thời gian
- ✓ Tính tổng tiền tự động

### 👥 Quản Lý Nhân Viên (Quản Lý)
- ✓ Thêm nhân viên
- ✓ Xóa nhân viên
- ✓ Xem danh sách nhân viên

### 📊 Báo Cáo & Thống Kê (Quản Lý)
- ✓ Báo cáo doanh thu theo tháng/năm
- ✓ Chi tiết từng đơn đặt
- ✓ Tổng doanh thu

### 👤 Khách Hàng
- ✓ Xem lịch sử giao dịch
- ✓ Xem thông tin tài khoản
- ✓ Xóa tài khoản (Soft Delete)

### 👁️ Xem Thông Tin
- ✓ Xem danh sách phòng
- ✓ Xem danh sách đơn đặt
- ✓ Xem thông tin tài khoản (polymorphic)

## 💾 Dữ Liệu Mẫu

### Người Dùng (3)
- Quản Lý: SĐT 0123456789, Pass admin123
- Nhân Viên: SĐT 0987654321, Pass staff123
- Khách Hàng: SĐT 0911111111, Pass customer123

### Phòng (6)
- P101, P102: Đơn (500.000 VND)
- P201, P202: Đôi (800.000 VND)
- P301, P302: VIP (1.500.000 VND)

## 📈 Thống Kê Dự Án

| Metric | Giá Trị |
|--------|--------|
| Classes | 7 chính |
| Methods | 40+ |
| Exceptions | 7 custom |
| Enums | 5 types |
| Menu Items | 20+ |
| Lines of Code | ~2,500 |
| Build Status | ✅ Success |
| Test Status | ✅ Hoạt động |

## 🎯 Quy Trình Kiểm Thử

### Test 1: User Registration
✅ Đăng ký khách hàng mới với SĐT duy nhất

### Test 2: Login
✅ Đăng nhập với tài khoản khách hàng
✅ Chuyển đến menu khách hàng đúng

### Test 3: Book Room
✅ Đặt phòng với ngày hợp lệ
✅ Tính tổng tiền đúng
✅ Phòng không bị trùng lịch

### Test 4: Cancel Booking
✅ Hủy phòng trong 24h trước
✅ Không thể hủy sau 24h

### Test 5: Offline Booking
✅ Nhân viên đặt phòng cho khách vãng lai
✅ Không cần tài khoản

### Test 6: Room Management
✅ Quản lý thêm/sửa/xóa phòng
✅ Không thể xóa phòng có khách

### Test 7: Revenue Report
✅ Báo cáo doanh thu theo tháng/năm
✅ Tính tổng đúng từ các đơn hoàn thành

## 📚 Tài Liệu

| File | Nội Dung |
|------|----------|
| **README.md** | Tổng quan & hướng dẫn cài đặt |
| **QUICK_START.md** | Bắt đầu nhanh trong 5 phút |
| **HUONG_DAN_CHI_TIET.md** | Hướng dẫn chi tiết từng chức năng |
| **KIEN_TRUC_HE_THONG.md** | Sơ đồ lớp, luồng, kiến trúc |
| **TONG_KET.md** | Tóm tắt & ghi chú |

## ✨ Điểm Nổi Bật

- 🎨 **Giao Diện Đẹp**: Console UI với bảng, icon, thông báo rõ ràng
- 🇻🇳 **Hỗ Trợ Tiếng Việt**: UTF-8 encoding đầy đủ
- 🛡️ **Bảo Mật**: Validation, access control, soft delete
- 🔧 **Dễ Mở Rộng**: Cấu trúc sạch, dễ thêm tính năng
- 📝 **Tài Liệu Đầy Đủ**: 5 file tài liệu chi tiết
- 🎯 **Đã Test**: Tất cả chức năng hoạt động tốt

## 🚀 Tiếp Theo (Optional)

1. **Database**: Thêm SQL Server/MySQL/SQLite
2. **Web API**: ASP.NET Core REST API
3. **Frontend**: React/Vue.js/Angular
4. **Mobile**: iOS/Android app
5. **Payment**: Stripe/Vnpay integration
6. **Notification**: Email/SMS

## 🎓 Học Được

- ✅ Object-Oriented Programming (OOP) đầy đủ
- ✅ Exception handling tốt
- ✅ Design patterns cơ bản
- ✅ Input validation
- ✅ Business logic complexity
- ✅ Code organization
- ✅ Documentation

## ✅ Kết Luận

Hệ thống hoàn chỉnh, sẵn sàng sử dụng, có tài liệu chi tiết, và đã test kỹ lưỡng. Phù hợp để học OOP, làm portfolio, hoặc mở rộng thành ứng dụng thực tế.

---

**Status**: ✅ HOÀN THÀNH  
**Version**: 1.0  
**Build**: Success (0 errors, 0 warnings)  
**Last Updated**: November 2024  
**Prepared by**: AI Assistant  

### 🎉 Sẵn Sàng Sử Dụng!

```bash
cd HotelBookingSystem
dotnet run
```

👉 **Bắt đầu test ngay bây giờ!**
