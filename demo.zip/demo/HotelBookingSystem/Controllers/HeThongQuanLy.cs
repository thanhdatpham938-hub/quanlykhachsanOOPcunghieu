using System;
using System.Collections.Generic;
using System.Linq;
using HotelBookingSystem.Models;
using HotelBookingSystem.Exceptions;

namespace HotelBookingSystem.Controllers
{
    /// <summary>
    /// Lớp điều khiển chính của hệ thống
    /// Quản lý tất cả logic xử lý: người dùng, phòng, đơn đặt phòng
    /// </summary>
    public class HeThongQuanLy
    {
        // Dữ liệu
        private List<NguoiDung> cacNguoiDung;
        private List<Phong> cacPhong;
        private List<DonDatPhong> cacDonDat;
        private NguoiDung? nguoiDungDangNhap;

        // Constructor
        public HeThongQuanLy()
        {
            cacNguoiDung = new List<NguoiDung>();
            cacPhong = new List<Phong>();
            cacDonDat = new List<DonDatPhong>();
            nguoiDungDangNhap = null;

            // Khởi tạo dữ liệu mẫu
            KhoiTaoDuLieuMau();
        }

        /// <summary>
        /// Khởi tạo dữ liệu mẫu để test
        /// </summary>
        private void KhoiTaoDuLieuMau()
        {
            // Thêm người dùng mẫu
            try
            {
                cacNguoiDung.Add(new QuanLy("Nguyễn Văn A", "0123456789", "admin123"));
                cacNguoiDung.Add(new NhanVien("Trần Thị B", "0987654321", "staff123"));
                cacNguoiDung.Add(new KhachHang("Lê Văn C", "0911111111", "customer123"));
            }
            catch { }

            // Thêm phòng mẫu
            cacPhong.Add(new Phong("P101", LoaiPhong.Don, 500000));
            cacPhong.Add(new Phong("P102", LoaiPhong.Don, 500000));
            cacPhong.Add(new Phong("P201", LoaiPhong.Doi, 800000));
            cacPhong.Add(new Phong("P202", LoaiPhong.Doi, 800000));
            cacPhong.Add(new Phong("P301", LoaiPhong.VIP, 1500000));
            cacPhong.Add(new Phong("P302", LoaiPhong.VIP, 1500000));
        }

        // ============ PHẦN ĐĂNG NHẬP / ĐĂNG KÝ ============

        /// <summary>
        /// Đăng ký tài khoản mới (chỉ dành cho khách hàng)
        /// Trả về (bool success, string message)
        /// </summary>
        public (bool success, string message) DangKy(string hoTen, string soDienThoai, string matKhau)
        {
            try
            {
                // Kiểm tra SĐT đã tồn tại
                if (cacNguoiDung.Any(u => u.SoDienThoai == soDienThoai))
                    throw new DuplicateIdException($"Số điện thoại {soDienThoai} đã được sử dụng!");

                // Kiểm tra mật khẩu
                if (string.IsNullOrWhiteSpace(matKhau) || matKhau.Length < 6)
                    throw new InvalidDataException("Mật khẩu phải có ít nhất 6 ký tự!");

                // Tạo khách hàng mới
                var khachHang = new KhachHang(hoTen, soDienThoai, matKhau);
                cacNguoiDung.Add(khachHang);

                var successMsg = $"✓ Đăng ký thành công! Chào mừng {hoTen}";
                Console.WriteLine(successMsg);
                return (true, "Đăng ký thành công!");
            }
            catch (DuplicateIdException ex)
            {
                Console.WriteLine($"✗ Lỗi đăng ký: {ex.Message}");
                return (false, ex.Message);
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"✗ Lỗi dữ liệu: {ex.Message}");
                return (false, ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Lỗi không xác định: {ex.Message}");
                return (false, ex.Message);
            }
        }

        /// <summary>
        /// Đăng nhập vào hệ thống
        /// </summary>
        public bool DangNhap(string soDienThoai, string matKhau)
        {
            try
            {
                var nguoiDung = cacNguoiDung.FirstOrDefault(u => u.SoDienThoai == soDienThoai);

                if (nguoiDung == null)
                    throw new InvalidLoginException("Sai số điện thoại hoặc mật khẩu!");

                nguoiDung.DangNhap(soDienThoai, matKhau);
                nguoiDungDangNhap = nguoiDung;
                return true;
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Đăng xuất khỏi hệ thống
        /// </summary>
        public void DangXuat()
        {
            if (nguoiDungDangNhap != null)
            {
                nguoiDungDangNhap.DangXuat();
                nguoiDungDangNhap = null;
            }
        }

        /// <summary>
        /// Lấy người dùng đang đăng nhập
        /// </summary>
        public NguoiDung? LayNguoiDungDangNhap()
        {
            return nguoiDungDangNhap;
        }

        // ============ PHẦN QUẢN LÝ PHÒNG ============

        /// <summary>
        /// Thêm phòng mới
        /// </summary>
        public void ThemPhongMoi(string maPhong, LoaiPhong loaiPhong, decimal giaTien)
        {
            try
            {
                // Kiểm tra mã phòng trùng
                if (cacPhong.Any(p => p.MaPhong == maPhong))
                    throw new DuplicateIdException($"Mã phòng {maPhong} đã tồn tại!");

                var phong = new Phong(maPhong, loaiPhong, giaTien);
                cacPhong.Add(phong);
                Console.WriteLine($"✓ Thêm phòng {maPhong} thành công!");
            }
            catch (DuplicateIdException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"✗ Lỗi dữ liệu: {ex.Message}");
            }
        }

        /// <summary>
        /// Sửa thông tin phòng
        /// </summary>
        public void SuaPhongTin(string maPhong, LoaiPhong? loaiPhongMoi = null, decimal? giaTienMoi = null)
        {
            try
            {
                var phong = cacPhong.FirstOrDefault(p => p.MaPhong == maPhong);
                if (phong == null)
                    throw new ResourceNotFoundException($"Không tìm thấy phòng {maPhong}!");

                if (loaiPhongMoi.HasValue)
                    phong.LoaiPhong = loaiPhongMoi.Value;

                if (giaTienMoi.HasValue && giaTienMoi > 0)
                    phong.GiaTien = giaTienMoi.Value;

                Console.WriteLine($"✓ Cập nhật thông tin phòng {maPhong} thành công!");
            }
            catch (ResourceNotFoundException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"✗ Lỗi dữ liệu: {ex.Message}");
            }
        }

        /// <summary>
        /// Xóa phòng
        /// </summary>
        public void XoaPhongKhiSan(string maPhong)
        {
            try
            {
                var phong = cacPhong.FirstOrDefault(p => p.MaPhong == maPhong);
                if (phong == null)
                    throw new ResourceNotFoundException($"Không tìm thấy phòng {maPhong}!");

                // Kiểm tra phòng có đơn đặt trong tương lai
                var coDonTuongLai = cacDonDat.Any(d =>
                    d.Phong?.MaPhong == maPhong &&
                    d.TrangThaiDon == TrangThaiDon.DaDat &&
                    d.NgayCheckIn > DateTime.Now);

                if (coDonTuongLai)
                    throw new DataConstraintException($"Phòng {maPhong} đang được đặt, không thể xóa!");

                cacPhong.Remove(phong);
                Console.WriteLine($"✓ Xóa phòng {maPhong} thành công!");
            }
            catch (ResourceNotFoundException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (DataConstraintException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        /// <summary>
        /// Hiển thị danh sách phòng
        /// </summary>
        public void HienThiDanhSachPhong()
        {
            Console.WriteLine("\n=== DANH SÁCH PHÒNG ===");
            if (cacPhong.Count == 0)
            {
                Console.WriteLine("Chưa có phòng nào!");
                return;
            }

            Console.WriteLine("┌─────────┬──────────┬──────────────┬───────────────┐");
            Console.WriteLine("│ Mã Phòng │   Loại  │   Giá (VND)  │  Trạng Thái   │");
            Console.WriteLine("├─────────┼──────────┼──────────────┼───────────────┤");

            foreach (var phong in cacPhong)
            {
                Console.WriteLine($"│ {phong.MaPhong,-7} │ {phong.LoaiPhong,-8} │ {phong.GiaTien,12:C0} │ {phong.TrangThaiHienTai,-13} │");
            }

            Console.WriteLine("└─────────┴──────────┴──────────────┴───────────────┘");
        }

        /// <summary>
        /// Tìm phòng trống theo khoảng thời gian
        /// </summary>
        public List<Phong> TimPhongTrong(DateTime checkIn, DateTime checkOut)
        {
            try
            {
                if (checkOut <= checkIn)
                    throw new InvalidDateException("Ngày Check-out phải lớn hơn ngày Check-in!");

                var phongTrong = new List<Phong>();

                foreach (var phong in cacPhong)
                {
                    if (phong.TrangThaiHienTai == TrangThaiPhong.SanSang &&
                        phong.KiemTraPhongTrong(checkIn, checkOut, cacDonDat))
                    {
                        phongTrong.Add(phong);
                    }
                }

                return phongTrong;
            }
            catch (InvalidDateException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
                return new List<Phong>();
            }
        }

        // ============ PHẦN QUẢN LÝ ĐẶT PHÒNG ============

        /// <summary>
        /// Đặt phòng online (dành cho khách hàng)
        /// </summary>
        public void DatPhongOnline(DateTime checkIn, DateTime checkOut, string maPhong)
        {
            try
            {
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is KhachHang))
                    throw new InvalidLoginException("Bạn phải đăng nhập là khách hàng!");

                var phong = cacPhong.FirstOrDefault(p => p.MaPhong == maPhong);
                if (phong == null)
                    throw new ResourceNotFoundException($"Không tìm thấy phòng {maPhong}!");

                if (!phong.KiemTraPhongTrong(checkIn, checkOut, cacDonDat))
                    throw new RoomUnavailableException($"Phòng {maPhong} không trống trong khoảng thời gian này!");

                var khach = (KhachHang)nguoiDungDangNhap;
                var maDon = "ON_" + Guid.NewGuid().ToString().Substring(0, 8).ToUpper();
                var don = new DonDatPhong(maDon, khach, phong, checkIn, checkOut);

                cacDonDat.Add(don);
                khach.DatPhongOnline(don);

                Console.WriteLine("\n=== HOÁ ĐƠN TẠM TÍNH ===");
                don.HienThiThongTin();
                Console.WriteLine("✓ Đặt phòng thành công!");
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (ResourceNotFoundException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (RoomUnavailableException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (InvalidDateException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        /// <summary>
        /// Đặt phòng offline (dành cho nhân viên)
        /// </summary>
        public void DatPhongOffline(string tenKhach, string sdtKhach, string maPhong, 
                                   DateTime checkIn, DateTime checkOut)
        {
            try
            {
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is NhanVien))
                    throw new InvalidLoginException("Bạn phải đăng nhập là nhân viên!");

                var phong = cacPhong.FirstOrDefault(p => p.MaPhong == maPhong);
                if (phong == null)
                    throw new ResourceNotFoundException($"Không tìm thấy phòng {maPhong}!");

                if (!phong.KiemTraPhongTrong(checkIn, checkOut, cacDonDat))
                    throw new RoomUnavailableException($"Phòng {maPhong} không trống trong khoảng thời gian này!");

                var nhanVien = (NhanVien)nguoiDungDangNhap;
                var don = nhanVien.DatPhongOffline(tenKhach, sdtKhach, phong, checkIn, checkOut);

                cacDonDat.Add(don);

                Console.WriteLine("\n=== HOÁ ĐƠN OFFLINE ===");
                don.HienThiThongTin();
                Console.WriteLine("✓ Tạo đơn thành công!");
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (ResourceNotFoundException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (RoomUnavailableException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (InvalidDateException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        /// <summary>
        /// Hủy đơn đặt phòng
        /// </summary>
        public void HuyDatPhong(string maDon)
        {
            try
            {
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is KhachHang))
                    throw new InvalidLoginException("Bạn phải đăng nhập để hủy đơn!");

                var khach = (KhachHang)nguoiDungDangNhap;
                khach.HuyDatPhong(maDon);
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (ResourceNotFoundException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        /// <summary>
        /// Hoàn thành đơn đặt phòng
        /// </summary>
        public void HoanThanhDonDat(string maDon)
        {
            try
            {
                var don = cacDonDat.FirstOrDefault(d => d.MaDon == maDon);
                if (don == null)
                    throw new ResourceNotFoundException($"Không tìm thấy đơn {maDon}!");

                don.TrangThaiDon = TrangThaiDon.DaHoanThanh;
                Console.WriteLine($"✓ Đơn {maDon} đã hoàn thành!");
            }
            catch (ResourceNotFoundException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        /// <summary>
        /// Xem lịch sử đặt phòng của khách hàng hiện tại
        /// </summary>
        public void XemLichSuDatPhong()
        {
            try
            {
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is KhachHang))
                    throw new InvalidLoginException("Bạn phải đăng nhập là khách hàng!");

                var khach = (KhachHang)nguoiDungDangNhap;
                khach.XemLichSu();
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        // ============ PHẦN QUẢN LÝ NHÂN VIÊN ============

        /// <summary>
        /// Thêm nhân viên mới
        /// </summary>
        public void ThemNhanVienMoi(string hoTen, string soDienThoai, string matKhau)
        {
            try
            {
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is QuanLy))
                    throw new InvalidLoginException("Bạn phải đăng nhập là quản lý!");

                if (cacNguoiDung.Any(u => u.SoDienThoai == soDienThoai))
                    throw new DuplicateIdException($"SĐT {soDienThoai} đã tồn tại!");

                var nhanVien = new NhanVien(hoTen, soDienThoai, matKhau);
                cacNguoiDung.Add(nhanVien);
                Console.WriteLine($"✓ Thêm nhân viên {hoTen} thành công!");
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (DuplicateIdException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine($"✗ Lỗi dữ liệu: {ex.Message}");
            }
        }

        /// <summary>
        /// Xóa nhân viên
        /// </summary>
        public void XoaNhanVien(string soDienThoai)
        {
            try
            {
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is QuanLy))
                    throw new InvalidLoginException("Bạn phải đăng nhập là quản lý!");

                var nhanVien = cacNguoiDung.FirstOrDefault(u => u.SoDienThoai == soDienThoai && u.VaiTro == VaiTro.NhanVien);
                if (nhanVien == null)
                    throw new ResourceNotFoundException($"Không tìm thấy nhân viên SĐT {soDienThoai}!");

                cacNguoiDung.Remove(nhanVien);
                Console.WriteLine($"✓ Xóa nhân viên thành công!");
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
            catch (ResourceNotFoundException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        /// <summary>
        /// Hiển thị danh sách nhân viên
        /// </summary>
        public void HienThiDanhSachNhanVien()
        {
            var danhSachNV = cacNguoiDung.Where(u => u.VaiTro == VaiTro.NhanVien).ToList();

            Console.WriteLine("\n=== DANH SÁCH NHÂN VIÊN ===");
            if (danhSachNV.Count == 0)
            {
                Console.WriteLine("Chưa có nhân viên nào!");
                return;
            }

            Console.WriteLine("┌────────────────────────┬────────────────┬──────────────────┐");
            Console.WriteLine("│      Họ Tên            │      SĐT       │    Trạng Thái    │");
            Console.WriteLine("├────────────────────────┼────────────────┼──────────────────┤");

            foreach (var nv in danhSachNV)
            {
                Console.WriteLine($"│ {nv.HoTen,-22} │ {nv.SoDienThoai,-14} │ {nv.TrangThaiTaiKhoan,-16} │");
            }

            Console.WriteLine("└────────────────────────┴────────────────┴──────────────────┘");
        }

        /// <summary>
        /// Lấy danh sách nhân viên (cho Window Form)
        /// </summary>
        public List<NguoiDung> LayDanhSachNhanVien()
        {
            return cacNguoiDung.Where(u => u.VaiTro == VaiTro.NhanVien).ToList();
        }

        /// <summary>
        /// Lấy danh sách phòng (cho Window Form)
        /// </summary>
        public List<Phong> LayDanhSachPhong()
        {
            return cacPhong;
        }

        // ============ PHẦN BÁO CÁO ============

        /// <summary>
        /// Xem báo cáo doanh thu
        /// </summary>
        public void XemBaoCaoDoanhThu(int thang, int nam)
        {
            try
            {
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is QuanLy))
                    throw new InvalidLoginException("Bạn phải đăng nhập là quản lý!");

                var quanLy = (QuanLy)nguoiDungDangNhap;
                // Gọi phương thức trả về chuỗi báo cáo (bao gồm đơn đã đặt và đã hoàn thành)
                var report = quanLy.TaoBaoCaoDoanhThu(cacDonDat, thang, nam, includePending: true);
                Console.WriteLine(report);
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"✗ Lỗi: {ex.Message}");
            }
        }

        /// <summary>
        /// Tạo báo cáo doanh thu dưới dạng chuỗi để UI có thể hiển thị.
        /// includePending = true sẽ tính cả đơn đang ở trạng thái 'ĐãĐặt'.
        /// </summary>
        public string TaoBaoCaoDoanhThu(int thang, int nam, bool includePending = true)
        {
            if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is QuanLy))
                throw new InvalidLoginException("Bạn phải đăng nhập là quản lý!");

            var quanLy = (QuanLy)nguoiDungDangNhap;
            return quanLy.TaoBaoCaoDoanhThu(cacDonDat, thang, nam, includePending);
        }

        /// <summary>
        /// Hiển thị danh sách đơn đặt
        /// </summary>
        public void HienThiDanhSachDonDat()
        {
            Console.WriteLine("\n=== DANH SÁCH ĐƠN ĐẶT ===");
            if (cacDonDat.Count == 0)
            {
                Console.WriteLine("Chưa có đơn đặt nào!");
                return;
            }

            foreach (var don in cacDonDat)
            {
                Console.WriteLine("─────────────────────────────────");
                don.HienThiThongTin();
            }
        }

        /// <summary>
        /// Lấy danh sách đơn đặt (cho Window Form)
        /// </summary>
        public List<DonDatPhong> LayDanhSachDonDat()
        {
            return cacDonDat;
        }
    }
}
