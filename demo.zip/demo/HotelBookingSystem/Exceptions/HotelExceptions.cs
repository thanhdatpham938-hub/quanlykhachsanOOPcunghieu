using System;

namespace HotelBookingSystem.Exceptions
{
    /// <summary>
    /// Ngoại lệ khi đăng nhập thất bại (Sai SĐT hoặc mật khẩu)
    /// </summary>
    public class InvalidLoginException : Exception
    {
        public InvalidLoginException(string message = "Sai số điện thoại hoặc mật khẩu!") 
            : base(message) { }
    }

    /// <summary>
    /// Ngoại lệ khi SĐT hoặc ID đã tồn tại
    /// </summary>
    public class DuplicateIdException : Exception
    {
        public DuplicateIdException(string message = "ID hoặc SĐT này đã tồn tại trong hệ thống!")
            : base(message) { }
    }

    /// <summary>
    /// Ngoại lệ khi phòng không còn trống trong khoảng thời gian yêu cầu
    /// </summary>
    public class RoomUnavailableException : Exception
    {
        public RoomUnavailableException(string message = "Phòng này không có sẵn trong khoảng thời gian đó!")
            : base(message) { }
    }

    /// <summary>
    /// Ngoại lệ khi vi phạm ràng buộc dữ liệu (vd: xóa phòng đang có khách)
    /// </summary>
    public class DataConstraintException : Exception
    {
        public DataConstraintException(string message = "Không thể xóa dữ liệu này do có ràng buộc từ dữ liệu khác!")
            : base(message) { }
    }

    /// <summary>
    /// Ngoại lệ khi dữ liệu không hợp lệ (vd: ngày Check-out nhỏ hơn Check-in)
    /// </summary>
    public class InvalidDataException : Exception
    {
        public InvalidDataException(string message = "Dữ liệu không hợp lệ!")
            : base(message) { }
    }

    /// <summary>
    /// Ngoại lệ khi ngày không hợp lệ
    /// </summary>
    public class InvalidDateException : Exception
    {
        public InvalidDateException(string message = "Ngày Check-out phải lớn hơn ngày Check-in!")
            : base(message) { }
    }

    /// <summary>
    /// Ngoại lệ khi không tìm thấy tài nguyên
    /// </summary>
    public class ResourceNotFoundException : Exception
    {
        public ResourceNotFoundException(string message = "Không tìm thấy tài nguyên!")
            : base(message) { }
    }
}
