# Hướng Dẫn Chi Tiết Sử Dụng Hệ Thống

## 🎬 Bắt Đầu Nhanh

### 1️⃣ Build Dự Án

```bash
cd HotelBookingSystem
dotnet build
```

### 2️⃣ Chạy Ứng Dụng

```bash
dotnet run
```

## 📖 Tài Khoản Test

### Quản Lý
```
SĐT: 0123456789
Mật khẩu: admin123
```

### Nhân Viên
```
SĐT: 0987654321
Mật khẩu: staff123
```

### Khách Hàng
```
SĐT: 0911111111
Mật khẩu: customer123
```

## 🎯 Quy Trình Chi Tiết

### A. ĐĂNG KÝ KHÁCH HÀNG MỚI

1. Menu Chính → Chọn "2. Đăng Ký Tài Khoản"
2. Nhập Họ tên: Ví dụ "Nguyễn Văn D"
3. Nhập SĐT: Ví dụ "0933333333"
4. Nhập Mật khẩu: Tối thiểu 6 ký tự, ví dụ "123456"
5. Xác nhận mật khẩu
6. ✓ Đăng ký thành công!

### B. ĐĂNG NHẬP & ĐẶT PHÒNG (Khách Hàng)

1. Menu Chính → Chọn "1. Đăng Nhập"
2. Nhập SĐT & Mật khẩu
3. Nhập vào Menu Khách Hàng
4. Chọn "1. Đặt Phòng Online"
5. Nhập ngày Check-in: 25/12/2024
6. Nhập ngày Check-out: 28/12/2024
7. Chọn phòng từ danh sách
8. ✓ Đặt phòng thành công!
9. Hoá đơn tạm tính sẽ được hiển thị

### C. HỦY PHÒNG (Khách Hàng)

1. Menu Khách Hàng → Chọn "2. Xem Trạng Thái & Hủy Phòng"
2. Xem danh sách đơn đang đặt
3. Nhập Mã đơn cần hủy (VD: ON_XXXXXXXX)
4. ✓ Phòng hủy thành công (nếu còn 24 giờ trước Check-in)

⚠️ **Lưu ý**: Chỉ có thể hủy trước 24 giờ Check-in

### D. ĐẶT PHÒNG OFFLINE (Nhân Viên)

1. Đăng nhập với tài khoản nhân viên
2. Menu Nhân Viên → Chọn "1. Đặt Phòng Offline (Tại Quầy)"
3. Nhập Tên khách vãng lai
4. Nhập SĐT khách
5. Nhập ngày Check-in/Check-out
6. Chọn phòng
7. ✓ Đơn offline được tạo!

### E. QUẢN LÝ PHÒNG (Quản Lý)

#### Thêm Phòng Mới
1. Đăng nhập quản lý
2. Menu Quản Lý → Chọn "1. Thêm Phòng"
3. Nhập Mã phòng: P401
4. Chọn Loại: 1 (Đơn), 2 (Đôi), 3 (VIP)
5. Nhập Giá tiền: 600000
6. ✓ Thêm thành công!

#### Sửa Giá Phòng
1. Menu Quản Lý → Chọn "2. Sửa Thông Tin Phòng"
2. Nhập Mã phòng cần sửa: P101
3. Nhập Giá mới: 550000 (hoặc bỏ trống nếu không đổi)
4. ✓ Cập nhật thành công!

#### Xóa Phòng
1. Menu Quản Lý → Chọn "3. Xóa Phòng"
2. Nhập Mã phòng: P401
3. ✓ Xóa thành công (nếu phòng không có đơn đặt)

⚠️ **Lưu ý**: Không thể xóa phòng đang có khách đặt

### F. QUẢN LÝ NHÂN VIÊN (Quản Lý)

#### Thêm Nhân Viên
1. Menu Quản Lý → Chọn "5. Thêm Nhân Viên"
2. Nhập Họ tên: Trần Văn E
3. Nhập SĐT: 0944444444
4. Nhập Mật khẩu
5. ✓ Thêm nhân viên thành công!

#### Xóa Nhân Viên
1. Menu Quản Lý → Chọn "6. Xóa Nhân Viên"
2. Xem danh sách nhân viên
3. Nhập SĐT nhân viên cần xóa
4. ✓ Xóa thành công!

### G. XEM BÁO CÁO DOANH THU (Quản Lý)

1. Menu Quản Lý → Chọn "8. Xem Báo Cáo Doanh Thu"
2. Nhập Tháng: 12
3. Nhập Năm: 2024
4. Xem Chi tiết:
   - Danh sách các đơn hoàn thành
   - Tổng số hóa đơn
   - Tổng doanh thu

## ⚠️ Xử Lý Lỗi Thường Gặp

### "Sai số điện thoại hoặc mật khẩu!"
- ✓ Kiểm tra lại SĐT & mật khẩu
- ✓ Xem lại danh sách tài khoản mẫu
- ✓ Đăng ký tài khoản mới nếu cần

### "SĐT này đã tồn tại trong hệ thống!"
- ✓ Dùng SĐT khác khi đăng ký

### "Phòng này không có sẵn trong khoảng thời gian đó!"
- ✓ Chọn ngày khác
- ✓ Chọn phòng khác từ danh sách
- ✓ Kiểm tra phòng đã được đặt bởi ai

### "Mật khẩu phải có ít nhất 6 ký tự!"
- ✓ Nhập mật khẩu dài hơn

### "Ngày Check-out phải lớn hơn ngày Check-in!"
- ✓ Kiểm tra ngày Check-out > Check-in
- ✓ Định dạng: dd/MM/yyyy (VD: 25/12/2024)

### "Bạn chỉ được hủy đặt phòng trước 24 giờ!"
- ✓ Chỉ hủy được trước 24h Check-in
- ✓ Liên hệ quản lý nếu muốn hủy sau thời hạn

## 🔐 Bảo Mật & Qui Định

### Mật Khẩu
- Tối thiểu 6 ký tự
- Không được để trống
- Có thể thay đổi sau khi đăng nhập

### Số Điện Thoại
- Phải duy nhất trong hệ thống
- Dùng làm username khi đăng nhập
- Không được thay đổi

### Xóa Tài Khoản
- **Soft Delete**: Dữ liệu được giữ lại
- Tài khoản chuyển sang trạng thái "Vô hiệu hóa"
- Lịch sử giao dịch vẫn được dùng cho báo cáo

### Hủy Phòng
- Chỉ được hủy trong 24 giờ trước Check-in
- Sau 24h, liên hệ quản lý để xử lý

## 📊 Dữ Liệu Mẫu Sẵn Có

### Phòng Mẫu
| Mã | Loại | Giá | Trạng Thái |
|----|------|-----|-----------|
| P101 | Đơn | 500.000 | Sẵn sàng |
| P102 | Đơn | 500.000 | Sẵn sàng |
| P201 | Đôi | 800.000 | Sẵn sàng |
| P202 | Đôi | 800.000 | Sẵn sàng |
| P301 | VIP | 1.500.000 | Sẵn sàng |
| P302 | VIP | 1.500.000 | Sẵn sàng |

## 🎓 Tính Năng OOP Được Sử Dụng

### ✓ Kế Thừa (Inheritance)
```
NguoiDung (Base)
├── KhachHang
├── NhanVien
└── QuanLy
```

### ✓ Đa Hình (Polymorphism)
- Override phương thức `HienThiThongTin()`
- Override phương thức `DangNhap()`

### ✓ Tính Đóng Gói (Encapsulation)
- Properties với getters/setters
- Validation trong constructor

### ✓ Trừu Tượng (Abstraction)
- Base class `NguoiDung` là abstract
- Interfaces qua exceptions

### ✓ Xử Lý Ngoại Lệ (Exception Handling)
- Custom exceptions cho từng tình huống
- Try-catch xử lý lỗi một cách graceful

## 📈 Thống Kê Lệnh Tính Toán

### Tính Tiền
```
Số đêm = Ngày Check-out - Ngày Check-in
Tổng tiền = Số đêm × Giá phòng
```

### Lọc Đơn Hoàn Thành
```
- Trạng thái = "Đã Hoàn Thành"
- Ngày Check-out nằm trong tháng/năm chỉ định
```

## 🆘 Liên Hệ & Hỗ Trợ

Nếu gặp vấn đề:
1. Kiểm tra lại dữ liệu nhập vào
2. Xem lại hướng dẫn chi tiết
3. Đảm bảo tài khoản có đủ quyền hạn
4. Thử lại hoặc khởi động lại ứng dụng

---

**Phiên Bản**: 1.0  
**Cập Nhật**: Tháng 11, 2024
