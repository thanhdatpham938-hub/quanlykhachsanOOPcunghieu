# 🏗️ Kiến Trúc & Thiết Kế Hệ Thống

## 📋 Sơ Đồ Lớp (Class Diagram)

```
┌─────────────────────────────────────────────────────────────┐
│                     NguoiDung (Abstract)                    │
│                    ─────────────────────                    │
│  Attributes:                                                │
│  - HoTen: string                                            │
│  - SoDienThoai: string (Key)                                │
│  - MatKhau: string                                          │
│  - VaiTro: enum (KhachHang, NhanVien, QuanLy)              │
│  - TrangThaiTaiKhoan: enum (HoatDong, VoHieuHoa)           │
│                                                             │
│  Methods:                                                   │
│  + DangNhap(sdt, pass): bool                               │
│  + DangXuat(): void                                         │
│  + DoiMatKhau(matKhauCu, matKhauMoi): void               │
│  + HienThiThongTin(): void (virtual)                       │
└─────────────────────────────────────────────────────────────┘
         △              △                △
         │              │                │
    ┌────┴────┐   ┌────┴────┐    ┌─────┴─────┐
    │          │   │         │    │           │
    │          │   │         │    │           │
┌───┴────┐ ┌──┴──┐│   ┌──────┴─┐  │
│KhachHang  NhanVien   │ QuanLy  │
└─────────┘ ──────────  └─────────┘

┌──────────────────────────┐    ┌──────────────────────────┐
│       Phong (Room)       │    │  DonDatPhong (Booking)   │
│  ──────────────────────  │    │  ──────────────────────  │
│  - MaPhong: string       │    │  - MaDon: string         │
│  - LoaiPhong: enum       │    │  - KhachHang: ref?       │
│  - GiaTien: decimal      │    │  - TenKhachVangLai: str  │
│  - TrangThaiHienTai: enum│    │  - Phong: ref            │
│                          │    │  - NgayCheckIn: DateTime │
│  + KiemTraPhongTrong()   │◄───┤  - NgayCheckOut: DateTime│
│  + HienThiThongTin()     │    │  - TongTien: decimal     │
└──────────────────────────┘    │  - TrangThaiDon: enum    │
                                 │                          │
                                 │  + TinhTongTien(): void  │
                                 │  + HienThiThongTin()     │
                                 └──────────────────────────┘

┌──────────────────────────────────────────┐
│      HeThongQuanLy (System Manager)      │
│  ──────────────────────────────────────  │
│  - cacNguoiDung: List<NguoiDung>        │
│  - cacPhong: List<Phong>                │
│  - cacDonDat: List<DonDatPhong>         │
│  - nguoiDungDangNhap: NguoiDung?        │
│                                          │
│  + DangNhap/DangKy()                    │
│  + ThemPhongMoi/SuaPhong/XoaPhong()     │
│  + DatPhongOnline/DatPhongOffline()     │
│  + ThemNhanVien/XoaNhanVien()           │
│  + XemBaoCaoDoanhThu()                  │
│  + HienThiDanhSachPhong()               │
│  + ... (nhiều phương thức khác)         │
└──────────────────────────────────────────┘
```

## 🎯 Mối Quan Hệ Giữa Các Lớp

### 1. **Composition (Bao Gồm)**

```
DonDatPhong "contains" Phong
DonDatPhong "contains" KhachHang (optional)
HeThongQuanLy "manages" List<NguoiDung>
HeThongQuanLy "manages" List<Phong>
HeThongQuanLy "manages" List<DonDatPhong>
```

### 2. **Association (Liên Kết)**

```
KhachHang "has many" DonDatPhong (qua LichSuGiaoDich)
NhanVien "creates" DonDatPhong (khi đặt phòng offline)
QuanLy "manages" Phong (CRUD)
QuanLy "manages" NhanVien (thêm/xóa)
```

## 🔄 Luồng Xử Lý Chính

### Luồng Đăng Nhập
```
Menu Chính
    ↓
Nhập SĐT & Mật khẩu
    ↓
HeThongQuanLy.DangNhap()
    ↓
Tìm NguoiDung trong danh sách
    ↓
Kiểm tra mật khẩu & trạng thái
    ↓
✓ Thành công → Menu theo vai trò
✗ Thất bại → Exception → Menu Chính
```

### Luồng Đặt Phòng (Khách Hàng)
```
Menu Khách Hàng
    ↓
"1. Đặt Phòng Online"
    ↓
Nhập ngày Check-in/Check-out
    ↓
HeThongQuanLy.TimPhongTrong()
    ├─ Kiểm tra từng phòng
    └─ So sánh khoảng thời gian
    ↓
Hiển thị danh sách phòng trống
    ↓
Chọn phòng
    ↓
Tạo DonDatPhong mới
    ├─ TinhTongTien()
    └─ TrangThaiDon = "DaDat"
    ↓
Hiển thị hoá đơn
    ↓
Thêm vào cacDonDat
    ↓
✓ Đặt phòng thành công
```

### Luồng Hủy Phòng
```
Menu Khách Hàng
    ↓
"2. Hủy Phòng"
    ↓
Xem lịch sử giao dịch
    ↓
Nhập mã đơn
    ↓
KhachHang.HuyDatPhong()
    ↓
Kiểm tra ràng buộc (24h trước Check-in)
    ├─ Nếu OK → TrangThaiDon = "DaHuy"
    └─ Nếu sai → InvalidDataException
    ↓
Hiển thị kết quả
```

### Luồng Báo Cáo Doanh Thu
```
Menu Quản Lý
    ↓
"8. Báo Cáo Doanh Thu"
    ↓
Nhập tháng/năm
    ↓
QuanLy.XemBaoCaoDoanhThu()
    ↓
Duyệt cacDonDat
    ├─ Lọc: TrangThaiDon == "DaHoanThanh"
    ├─ Lọc: NgayCheckOut.Month == tháng
    ├─ Lọc: NgayCheckOut.Year == năm
    └─ Cộng dồn TongTien
    ↓
Hiển thị:
├─ Danh sách từng đơn
├─ Số hóa đơn
└─ Tổng doanh thu
```

## 🛡️ Xử Lý Ngoại Lệ

### Exception Hierarchy

```
Exception (Base từ .NET)
    ├─ InvalidLoginException
    │   └─ "Sai SĐT hoặc mật khẩu"
    │
    ├─ DuplicateIdException
    │   └─ "SĐT hoặc ID đã tồn tại"
    │
    ├─ RoomUnavailableException
    │   └─ "Phòng không trống"
    │
    ├─ DataConstraintException
    │   └─ "Vi phạm ràng buộc dữ liệu"
    │
    ├─ InvalidDataException
    │   └─ "Dữ liệu không hợp lệ"
    │
    ├─ InvalidDateException
    │   └─ "Ngày không hợp lệ"
    │
    └─ ResourceNotFoundException
        └─ "Không tìm thấy tài nguyên"
```

### Ví Dụ Try-Catch

```csharp
try
{
    heThong.DatPhongOnline(checkIn, checkOut, maPhong);
}
catch (InvalidDateException ex)
{
    Console.WriteLine($"✗ Lỗi: {ex.Message}");
}
catch (RoomUnavailableException ex)
{
    Console.WriteLine($"✗ Lỗi: {ex.Message}");
}
catch (Exception ex)
{
    Console.WriteLine($"✗ Lỗi không xác định: {ex.Message}");
}
```

## 📐 Mô Hình Vai Trò (Role Model)

### Khách Hàng (Customer)
```
Quyền hạn:
✓ Đăng ký tài khoản
✓ Đăng nhập
✓ Đặt phòng online
✓ Xem & hủy đơn đặt (24h trước Check-in)
✓ Xem lịch sử giao dịch
✓ Xóa tài khoản (Soft Delete)
✗ Không được quản lý phòng
✗ Không được quản lý nhân viên
✗ Không được xem báo cáo doanh thu
```

### Nhân Viên (Staff)
```
Quyền hạn:
✓ Đăng nhập
✓ Đặt phòng offline (tại quầy) cho khách vãng lai
✓ Xem danh sách phòng
✓ Xem danh sách đơn đặt
✗ Không được thay đổi thông tin phòng
✗ Không được quản lý nhân viên
✗ Không được xem báo cáo doanh thu
```

### Quản Lý (Manager)
```
Quyền hạn:
✓ Đăng nhập
✓ CRUD phòng (Thêm/Sửa/Xóa)
✓ Quản lý nhân viên (Thêm/Xóa)
✓ Xem danh sách nhân viên
✓ Xem báo cáo doanh thu theo tháng/năm
✓ Xem danh sách đơn đặt
✓ Tất cả quyền hạn khác
```

## 💾 Cấu Trúc Dữ Liệu

### Dữ Liệu Lưu Trữ Trong Bộ Nhớ (In-Memory)

```
HeThongQuanLy
├── cacNguoiDung: List<NguoiDung>
│   ├── [0] QuanLy (0123456789)
│   ├── [1] NhanVien (0987654321)
│   ├── [2] KhachHang (0911111111)
│   └── [n] KhachHang (...)
│
├── cacPhong: List<Phong>
│   ├── P101 (Don, 500000)
│   ├── P102 (Don, 500000)
│   ├── P201 (Doi, 800000)
│   ├── P202 (Doi, 800000)
│   ├── P301 (VIP, 1500000)
│   └── P302 (VIP, 1500000)
│
└── cacDonDat: List<DonDatPhong>
    ├── ON_XXXXXXXX (KhachHang, P201, ...)
    ├── OFF_YYYYYYYY (Khach Vang Lai, P101, ...)
    └── ... (...)
```

⚠️ **Lưu Ý**: Dữ liệu hiện tại được lưu trong **bộ nhớ RAM**. Khi tắt ứng dụng, tất cả dữ liệu sẽ mất. 

**Bước tiếp theo**: Có thể thêm **Database** (SQL Server, MySQL, SQLite) để lưu trữ vĩnh viễn.

## 🔐 Tính Năng Bảo Mật

### 1. Validation Input
```
- SĐT phải duy nhất
- Mật khẩu tối thiểu 6 ký tự
- Ngày Check-out > Check-in
- Giá tiền phải > 0
```

### 2. Access Control
```
- Kiểm tra vai trò trước khi thực hiện action
- Chỉ Quản Lý mới được CRUD phòng
- Chỉ Nhân Viên mới được đặt offline
- Chỉ Khách Hàng mới được đặt online
```

### 3. Soft Delete
```
- Xóa tài khoản không xóa vĩnh viễn
- Dữ liệu vẫn được lưu cho báo cáo
- TrangThaiTaiKhoan = "VoHieuHoa"
```

### 4. Business Logic Constraints
```
- Không thể xóa phòng đang có khách
- Chỉ hủy phòng trong 24h trước Check-in
- Phòng bảo trì không thể đặt
```

## 📊 Ví Dụ Tính Toán

### Ví Dụ 1: Tính Tiền Phòng

```
Check-in: 25/12/2024
Check-out: 28/12/2024
Giá phòng: 800.000 VND

Số đêm = 28/12 - 25/12 = 3 đêm
Tổng tiền = 3 × 800.000 = 2.400.000 VND
```

### Ví Dụ 2: Kiểm Tra Trùng Lịch

```
Phòng P201 đã có đơn:
- Đơn 1: 20/12 - 25/12

Yêu cầu mới:
- Ngày: 23/12 - 27/12
→ Khoảng 23-27 trùng với 20-25
→ Phòng không trống!

Yêu cầu khác:
- Ngày: 25/12 - 30/12
→ Khoảng 25-30 không trùng (25 <= 25 OK)
→ Phòng trống! ✓
```

### Ví Dụ 3: Báo Cáo Doanh Thu

```
Tháng: 12, Năm: 2024

Duyệt cacDonDat:
✓ ON_ABC (Đã Hoàn Thành, CheckOut: 05/12/2024): 2.400.000
✓ OFF_DEF (Đã Hoàn Thành, CheckOut: 12/12/2024): 1.600.000
✗ ON_GHI (Đã Đặt, CheckOut: 20/12/2024): Skip (chưa hoàn thành)
✓ ON_JKL (Đã Hoàn Thành, CheckOut: 25/12/2024): 1.500.000

Kết quả:
Số hóa đơn: 3
Tổng doanh thu: 5.500.000 VND
```

## 🚀 Cách Mở Rộng Hệ Thống

### 1. Thêm Database
```csharp
// Thay thế List<T> bằng Database queries
// Sử dụng Entity Framework, Dapper, hoặc ADO.NET
```

### 2. Thêm Payment Gateway
```csharp
// Tích hợp Paypal, Stripe, Vnpay, v.v.
// Xác nhận thanh toán trước khi check-in
```

### 3. Thêm Email/SMS Notification
```csharp
// Gửi email xác nhận đơn đặt
// Gửi SMS nhắc nhở check-in
```

### 4. Thêm Web Interface
```csharp
// ASP.NET Core Web API
// React/Vue.js Frontend
```

### 5. Thêm Mobile App
```csharp
// Mobile API endpoints
// iOS/Android application
```

### 6. Thêm Analytics
```csharp
// Báo cáo chi tiết về:
// - Phòng được đặt nhiều nhất
// - Thời gian cao điểm
// - Khách hàng thường xuyên
// - v.v.
```

---

**Phiên Bản**: 1.0  
**Cập Nhật**: Tháng 11, 2024
