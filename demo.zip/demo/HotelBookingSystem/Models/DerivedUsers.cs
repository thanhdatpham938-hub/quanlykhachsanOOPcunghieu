using System;
using System.Collections.Generic;
using HotelBookingSystem.Exceptions;

namespace HotelBookingSystem.Models
{
    /// <summary>
    /// Lớp Khách Hàng kế thừa từ NguoiDung
    /// Chịu trách nhiệm về đặt phòng online và quản lý lịch sử đặt phòng
    /// </summary>
    public class KhachHang : NguoiDung
    {
        // Thuộc tính riêng
        public List<DonDatPhong> LichSuGiaoDich { get; set; }

        // Constructor
        public KhachHang(string hoTen, string soDienThoai, string matKhau)
            : base(hoTen, soDienThoai, matKhau, VaiTro.KhachHang)
        {
            LichSuGiaoDich = new List<DonDatPhong>();
        }

        // Phương thức
        /// <summary>
        /// Đặt phòng online (sẽ được gọi từ HeThongQuanLy)
        /// </summary>
        public void DatPhongOnline(DonDatPhong don)
        {
            if (don == null)
                throw new InvalidDataException("Đơn đặt phòng không hợp lệ!");

            LichSuGiaoDich.Add(don);
            Console.WriteLine($"✓ {HoTen} đã đặt phòng thành công!");
        }

        /// <summary>
        /// Hủy đặt phòng
        /// </summary>
        public bool HuyDatPhong(string maDon)
        {
            var don = LichSuGiaoDich.Find(d => d.MaDon == maDon && d.TrangThaiDon == TrangThaiDon.DaDat);

            if (don == null)
                throw new ResourceNotFoundException("Không tìm thấy đơn đặt phòng cần hủy!");

            // Kiểm tra thời gian hủy (ví dụ: trước 24h)
            var thoiGianConLai = don.NgayCheckIn - DateTime.Now;
            if (thoiGianConLai.TotalHours < 24)
            {
                throw new InvalidDataException("Bạn chỉ được hủy đặt phòng trước 24 giờ!");
            }

            don.TrangThaiDon = TrangThaiDon.DaHuy;
            Console.WriteLine($"✓ Đơn đặt phòng {maDon} đã bị hủy!");
            return true;
        }

        /// <summary>
        /// Xem lịch sử giao dịch
        /// </summary>
        public void XemLichSu()
        {
            Console.WriteLine($"\n=== LỊCH SỬ GIAO DỊCH CỦA {HoTen} ===");
            if (LichSuGiaoDich.Count == 0)
            {
                Console.WriteLine("Bạn chưa có đơn đặt phòng nào!");
                return;
            }

            foreach (var don in LichSuGiaoDich)
            {
                Console.WriteLine($"─────────────────────────────");
                don.HienThiThongTin();
            }
        }

        /// <summary>
        /// Xóa tài khoản (Soft Delete)
        /// </summary>
        public void XoaTaiKhoan()
        {
            TrangThaiTaiKhoan = TrangThaiTaiKhoan.VoHieuHoa;
            Console.WriteLine($"✓ Tài khoản của {HoTen} đã được xóa (Vô hiệu hóa)!");
        }

        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine($"Số đơn đặt phòng: {LichSuGiaoDich.Count}");
        }
    }

    /// <summary>
    /// Lớp Nhân Viên kế thừa từ NguoiDung
    /// Có khả năng đặt phòng offline thay mặt khách hàng
    /// </summary>
    public class NhanVien : NguoiDung
    {
        public NhanVien(string hoTen, string soDienThoai, string matKhau)
            : base(hoTen, soDienThoai, matKhau, VaiTro.NhanVien)
        {
        }

        /// <summary>
        /// Đặt phòng offline (tại quầy) thay mặt khách hàng vãng lai
        /// </summary>
        public DonDatPhong DatPhongOffline(string tenKhachVangLai, string sdtKhachVangLai, 
                                          Phong phong, DateTime checkIn, DateTime checkOut)
        {
            if (string.IsNullOrWhiteSpace(tenKhachVangLai))
                throw new InvalidDataException("Tên khách hàng không được để trống!");

            if (checkOut <= checkIn)
                throw new InvalidDateException("Ngày Check-out phải lớn hơn ngày Check-in!");

            var don = new DonDatPhong(
                maDon: "OFF_" + Guid.NewGuid().ToString().Substring(0, 8).ToUpper(),
                khachHang: null,  // Khách vãng lai không có tài khoản
                phong: phong,
                ngayCheckIn: checkIn,
                ngayCheckOut: checkOut,
                tenKhachVangLai: tenKhachVangLai,
                sdtKhachVangLai: sdtKhachVangLai
            );

            Console.WriteLine($"✓ {HoTen} đã tạo đơn đặt phòng offline cho khách vãng lai {tenKhachVangLai}!");
            return don;
        }

        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine($"Bộ phận: Nhân viên bán hàng");
        }
    }

    /// <summary>
    /// Lớp Quản Lý kế thừa từ NguoiDung
    /// Quản lý phòng, nhân viên và báo cáo doanh thu
    /// </summary>
    public class QuanLy : NguoiDung
    {
        public QuanLy(string hoTen, string soDienThoai, string matKhau)
            : base(hoTen, soDienThoai, matKhau, VaiTro.QuanLy)
        {
        }

        /// <summary>
        /// Thêm phòng mới
        /// </summary>
        public Phong ThemPhong(string maPhong, LoaiPhong loaiPhong, decimal giaTien)
        {
            if (string.IsNullOrWhiteSpace(maPhong))
                throw new InvalidDataException("Mã phòng không được để trống!");

            if (giaTien <= 0)
                throw new InvalidDataException("Giá tiền phải lớn hơn 0!");

            return new Phong(maPhong, loaiPhong, giaTien);
        }

        /// <summary>
        /// Sửa thông tin phòng
        /// </summary>
        public void SuaPhong(Phong phong, LoaiPhong? loaiPhongMoi = null, decimal? giaTienMoi = null)
        {
            if (phong == null)
                throw new InvalidDataException("Phòng không tồn tại!");

            if (loaiPhongMoi.HasValue)
                phong.LoaiPhong = loaiPhongMoi.Value;

            if (giaTienMoi.HasValue)
            {
                if (giaTienMoi <= 0)
                    throw new InvalidDataException("Giá tiền phải lớn hơn 0!");
                phong.GiaTien = giaTienMoi.Value;
            }

            Console.WriteLine($"✓ Thông tin phòng {phong.MaPhong} đã được cập nhật!");
        }

        /// <summary>
        /// Xóa phòng (chỉ khi phòng không có đơn đặt trong tương lai)
        /// </summary>
        public void XoaPhong(Phong phong, List<DonDatPhong> cacDonDat)
        {
            if (phong == null)
                throw new InvalidDataException("Phòng không tồn tại!");

            // Kiểm tra xem phòng có đơn đặt trong tương lai không
            var coDonTuongLai = cacDonDat.Exists(d => 
                d.Phong?.MaPhong == phong.MaPhong && 
                d.TrangThaiDon == TrangThaiDon.DaDat &&
                d.NgayCheckIn > DateTime.Now);

            if (coDonTuongLai)
                throw new DataConstraintException($"Phòng {phong.MaPhong} đang được đặt, không thể xóa!");

            Console.WriteLine($"✓ Phòng {phong.MaPhong} đã bị xóa khỏi hệ thống!");
        }

        /// <summary>
        /// Quản lý nhân viên (thêm, xóa)
        /// </summary>
        public NhanVien ThemNhanVien(string hoTen, string soDienThoai, string matKhau)
        {
            return new NhanVien(hoTen, soDienThoai, matKhau);
        }

        /// <summary>
        /// Xem báo cáo doanh thu theo tháng/năm và trả về chuỗi báo cáo.
        /// Nếu includePending = true thì sẽ bao gồm cả các đơn đang ở trạng thái "Đã Đặt".
        /// </summary>
        public string TaoBaoCaoDoanhThu(List<DonDatPhong> cacDonDat, int thang, int nam, bool includePending = false)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"BÁO CÁO DOANH THU THÁNG {thang}/{nam}");
            sb.AppendLine(new string('═', 40));

            decimal tongTien = 0;
            int soHoaDon = 0;

            foreach (var don in cacDonDat)
            {
                // Chỉ tính các đơn theo trạng thái: đã hoàn thành hoặc (tuỳ chọn) đang đặt
                bool trangThaiHopLe = (don.TrangThaiDon == TrangThaiDon.DaHoanThanh) ||
                                      (includePending && don.TrangThaiDon == TrangThaiDon.DaDat);

                if (trangThaiHopLe &&
                    don.NgayCheckOut.Month == thang &&
                    don.NgayCheckOut.Year == nam)
                {
                    tongTien += don.TongTien;
                    soHoaDon++;

                    sb.AppendLine($"- Phòng {don.Phong?.MaPhong}: {don.TongTien:C} VND " +
                        $"({don.NgayCheckIn:dd/MM/yyyy} - {don.NgayCheckOut:dd/MM/yyyy}) [{don.TrangThaiDon}]");
                }
            }

            sb.AppendLine("─────────────────────────────");
            sb.AppendLine($"Số hóa đơn: {soHoaDon}");
            sb.AppendLine($"Tổng doanh thu: {tongTien:C} VND");

            return sb.ToString();
        }

        public override void HienThiThongTin()
        {
            base.HienThiThongTin();
            Console.WriteLine($"Bộ phận: Quản lý");
        }
    }
}
