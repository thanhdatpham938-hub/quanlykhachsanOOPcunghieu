namespace HotelBookingSystem.Models
{
    /// <summary>
    /// Enum định nghĩa vai trò của người dùng
    /// </summary>
    public enum VaiTro
    {
        KhachHang,  // Khách hàng
        NhanVien,   // Nhân viên
        QuanLy      // Quản lý
    }

    /// <summary>
    /// Enum trạng thái phòng
    /// </summary>
    public enum TrangThaiPhong
    {
        SanSang,      // Sẵn sàng
        DangBaoTri    // Đang bảo trì
    }

    /// <summary>
    /// Enum trạng thái đơn đặt phòng
    /// </summary>
    public enum TrangThaiDon
    {
        DaDat,        // Đã đặt
        DaHuy,        // Đã hủy
        DaHoanThanh   // Đã hoàn thành
    }

    /// <summary>
    /// Enum loại phòng
    /// </summary>
    public enum LoaiPhong
    {
        Don,          // Phòng đơn
        Doi,          // Phòng đôi
        VIP           // Phòng VIP
    }

    /// <summary>
    /// Enum trạng thái tài khoản
    /// </summary>
    public enum TrangThaiTaiKhoan
    {
        HoatDong,     // Hoạt động
        VoHieuHoa     // Vô hiệu hóa
    }
}
