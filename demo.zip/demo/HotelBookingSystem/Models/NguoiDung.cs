using System;
using HotelBookingSystem.Exceptions;

namespace HotelBookingSystem.Models
{
    /// <summary>
    /// Lớp cơ sở cho tất cả người dùng trong hệ thống
    /// Sử dụng tính kế thừa và đa hình
    /// </summary>
    public abstract class NguoiDung
    {
        // Thuộc tính
        public string HoTen { get; set; }
        public string SoDienThoai { get; set; }  // Key - duy nhất
        public string MatKhau { get; set; }
        public VaiTro VaiTro { get; set; }
        public TrangThaiTaiKhoan TrangThaiTaiKhoan { get; set; }

        // Constructor
        public NguoiDung(string hoTen, string soDienThoai, string matKhau, VaiTro vaiTro)
        {
            if (string.IsNullOrWhiteSpace(hoTen))
                throw new InvalidDataException("Họ tên không được để trống!");
            
            if (string.IsNullOrWhiteSpace(soDienThoai))
                throw new InvalidDataException("Số điện thoại không được để trống!");
            
            if (string.IsNullOrWhiteSpace(matKhau) || matKhau.Length < 6)
                throw new InvalidDataException("Mật khẩu phải có ít nhất 6 ký tự!");

            HoTen = hoTen;
            SoDienThoai = soDienThoai;
            MatKhau = matKhau;
            VaiTro = vaiTro;
            TrangThaiTaiKhoan = TrangThaiTaiKhoan.HoatDong;
        }

        // Phương thức
        /// <summary>
        /// Đăng nhập hệ thống
        /// </summary>
        public virtual bool DangNhap(string sdt, string pass)
        {
            if (SoDienThoai == sdt && MatKhau == pass && TrangThaiTaiKhoan == TrangThaiTaiKhoan.HoatDong)
            {
                Console.WriteLine($"✓ Đăng nhập thành công! Chào mừng {HoTen}");
                return true;
            }
            throw new InvalidLoginException("Sai số điện thoại hoặc mật khẩu!");
        }

        /// <summary>
        /// Đăng xuất khỏi hệ thống
        /// </summary>
        public virtual void DangXuat()
        {
            Console.WriteLine($"✓ {HoTen} đã đăng xuất!");
        }

        /// <summary>
        /// Thay đổi mật khẩu
        /// </summary>
        public virtual void DoiMatKhau(string matKhauCu, string matKhauMoi)
        {
            if (MatKhau != matKhauCu)
                throw new InvalidLoginException("Mật khẩu cũ không đúng!");

            if (string.IsNullOrWhiteSpace(matKhauMoi) || matKhauMoi.Length < 6)
                throw new InvalidDataException("Mật khẩu mới phải có ít nhất 6 ký tự!");

            MatKhau = matKhauMoi;
            Console.WriteLine("✓ Mật khẩu đã được thay đổi thành công!");
        }

        // Phương thức ảo cho các lớp con override
        public virtual void HienThiThongTin()
        {
            Console.WriteLine($"\n=== THÔNG TIN NGƯỜI DÙNG ===");
            Console.WriteLine($"Họ Tên: {HoTen}");
            Console.WriteLine($"SĐT: {SoDienThoai}");
            Console.WriteLine($"Vai Trò: {VaiTro}");
            Console.WriteLine($"Trạng Thái: {TrangThaiTaiKhoan}");
        }
    }
}
