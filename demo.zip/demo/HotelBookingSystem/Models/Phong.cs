using System;
using HotelBookingSystem.Exceptions;

namespace HotelBookingSystem.Models
{
    /// <summary>
    /// Lớp đại diện cho một phòng trong khách sạn
    /// </summary>
    public class Phong
    {
        // Thuộc tính
        public string MaPhong { get; set; }          // ID phòng
        public LoaiPhong LoaiPhong { get; set; }     // Loại phòng (Don, Doi, VIP)
        public decimal GiaTien { get; set; }         // Giá tiền mỗi đêm
        public TrangThaiPhong TrangThaiHienTai { get; set; }  // Trạng thái (SanSang, DangBaoTri)

        // Constructor
        public Phong(string maPhong, LoaiPhong loaiPhong, decimal giaTien)
        {
            if (string.IsNullOrWhiteSpace(maPhong))
                throw new InvalidDataException("Mã phòng không được để trống!");

            if (giaTien <= 0)
                throw new InvalidDataException("Giá tiền phải lớn hơn 0!");

            MaPhong = maPhong;
            LoaiPhong = loaiPhong;
            GiaTien = giaTien;
            TrangThaiHienTai = TrangThaiPhong.SanSang;
        }

        /// <summary>
        /// Kiểm tra xem phòng có sẵn trong khoảng thời gian nào đó không
        /// </summary>
        public bool KiemTraPhongTrong(DateTime checkIn, DateTime checkOut, 
                                     System.Collections.Generic.List<DonDatPhong> cacDonDat)
        {
            foreach (var don in cacDonDat)
            {
                // Chỉ kiểm tra các đơn đã đặt và chưa bị hủy
                if (don.Phong?.MaPhong == MaPhong && don.TrangThaiDon == TrangThaiDon.DaDat)
                {
                    // Kiểm tra xem khoảng thời gian có trùng không
                    if (!(checkOut <= don.NgayCheckIn || checkIn >= don.NgayCheckOut))
                    {
                        return false;  // Phòng bị trùng lịch
                    }
                }
            }
            return true;  // Phòng trống
        }

        /// <summary>
        /// Hiển thị thông tin phòng
        /// </summary>
        public void HienThiThongTin()
        {
            Console.WriteLine($"Mã phòng: {MaPhong} | Loại: {LoaiPhong} | Giá: {GiaTien:C} VND/đêm | " +
                            $"Trạng thái: {TrangThaiHienTai}");
        }
    }

    /// <summary>
    /// Lớp đại diện cho một đơn đặt phòng
    /// </summary>
    public class DonDatPhong
    {
        // Thuộc tính
        public string MaDon { get; set; }                    // ID đơn
        public KhachHang? KhachHang { get; set; }            // Khách hàng (null nếu là khách vãng lai)
        public string? TenKhachVangLai { get; set; }         // Tên khách vãng lai
        public string? SdtKhachVangLai { get; set; }         // SĐT khách vãng lai
        public Phong? Phong { get; set; }                    // Phòng được đặt
        public DateTime NgayCheckIn { get; set; }            // Ngày nhận phòng
        public DateTime NgayCheckOut { get; set; }           // Ngày trả phòng
        public decimal TongTien { get; set; }                // Tổng tiền (tính toán)
        public TrangThaiDon TrangThaiDon { get; set; }       // Trạng thái đơn

        // Constructor
        public DonDatPhong(string maDon, KhachHang? khachHang, Phong phong, 
                          DateTime ngayCheckIn, DateTime ngayCheckOut,
                          string? tenKhachVangLai = null, string? sdtKhachVangLai = null)
        {
            if (string.IsNullOrWhiteSpace(maDon))
                throw new InvalidDataException("Mã đơn không được để trống!");

            if (phong == null)
                throw new InvalidDataException("Phòng không tồn tại!");

            if (ngayCheckOut <= ngayCheckIn)
                throw new InvalidDateException("Ngày Check-out phải lớn hơn ngày Check-in!");

            MaDon = maDon;
            KhachHang = khachHang;
            TenKhachVangLai = tenKhachVangLai;
            SdtKhachVangLai = sdtKhachVangLai;
            Phong = phong;
            NgayCheckIn = ngayCheckIn;
            NgayCheckOut = ngayCheckOut;
            TrangThaiDon = TrangThaiDon.DaDat;

            // Tính tổng tiền
            TinhTongTien();
        }

        /// <summary>
        /// Tính tổng tiền dựa trên số ngày và giá phòng
        /// </summary>
        public void TinhTongTien()
        {
            var soNgay = (NgayCheckOut - NgayCheckIn).Days;
            if (soNgay <= 0)
                soNgay = 1;

            TongTien = soNgay * Phong!.GiaTien;
        }

        /// <summary>
        /// Hiển thị thông tin đơn đặt
        /// </summary>
        public void HienThiThongTin()
        {
            Console.WriteLine($"Mã đơn: {MaDon}");
            
            if (KhachHang != null)
                Console.WriteLine($"Khách hàng: {KhachHang.HoTen} ({KhachHang.SoDienThoai})");
            else
                Console.WriteLine($"Khách vãng lai: {TenKhachVangLai} ({SdtKhachVangLai})");

            Console.WriteLine($"Phòng: {Phong?.MaPhong}");
            Console.WriteLine($"Check-in: {NgayCheckIn:dd/MM/yyyy}");
            Console.WriteLine($"Check-out: {NgayCheckOut:dd/MM/yyyy}");
            Console.WriteLine($"Số đêm: {(NgayCheckOut - NgayCheckIn).Days}");
            Console.WriteLine($"Tổng tiền: {TongTien:C} VND");
            Console.WriteLine($"Trạng thái: {TrangThaiDon}");
        }
    }
}
