# 🎯 HƯỚNG DẪN BẮT ĐẦU NHANH

## ⚡ Chạy Ngay

```bash
cd "c:\Users\DUY HIEU\OneDrive\Máy tính\demo\HotelBookingSystem"
dotnet build
dotnet run
```

**Ghi chú**: Ứng dụng sẽ mở cửa sổ Windows Forms thay vì console.

## 🔑 Tài Khoản Test (Đã Có Sẵn)

### 1️⃣ Quản Lý
- **SĐT**: 0923456789
- **Mật khẩu**: 123456
- **Quyền**: Quản lý phòng, nhân viên, báo cáo doanh thu

### 2️⃣ Nhân Viên
- **SĐT**: 0912345678
- **Mật khẩu**: 123456
- **Quyền**: Đặt phòng offline, xem danh sách

### 3️⃣ Khách Hàng
- **SĐT**: 0901234567
- **Mật khẩu**: 123456
- **Quyền**: Đặt phòng online, xem lịch sử, hủy phòng

## 📋 Các Bước Test Cơ Bản

### Test 1: Đặt Phòng Khách Hàng
```
1. Đăng nhập: SĐT 0901234567, Pass: 123456
2. Chọn "Đặt Phòng Online"
3. Chọn ngày Check-in và Check-out
4. Chọn phòng phù hợp
5. ✓ Xem hoá đơn
```

### Test 2: Hủy Phòng
```
1. Ở menu khách hàng, chọn "Xem/Hủy Đặt Phòng"
2. Chọn đơn đặt phòng muốn hủy
3. ✓ Phòng hủy thành công
```

### Test 3: Đặt Phòng Nhân Viên
```
1. Đăng nhập: SĐT 0912345678, Pass: 123456
2. Chọn "Đặt Phòng Offline"
3. Nhập thông tin khách hàng
4. Chọn phòng và ngày
5. ✓ Phòng được đặt
```

### Test 4: Xem Báo Cáo Doanh Thu
```
1. Đăng nhập: SĐT 0923456789, Pass: 123456
2. Chọn "Báo Cáo Doanh Thu"
3. Chọn tháng và năm
4. ✓ Xem doanh thu
```

## 🏨 Danh Sách Phòng Sẵn Có

| Mã | Loại | Giá | Chi Tiết |
|----|------|-----|---------|
| P101 | Đơn | 500.000 VND | Phòng đơn tiêu chuẩn |
| P102 | Đơn | 500.000 VND | Phòng đơn tiêu chuẩn |
| P201 | Đôi | 800.000 VND | Phòng đôi tiêu chuẩn |
| P202 | Đôi | 800.000 VND | Phòng đôi tiêu chuẩn |
| P301 | VIP | 1.500.000 VND | Phòng VIP cao cấp |
| P302 | VIP | 1.500.000 VND | Phòng VIP cao cấp |

## 🎓 Các Tính Năng OOP

### ✅ Đang Sử Dụng

- **Inheritance**: NguoiDung → KhachHang, NhanVien, QuanLy
- **Polymorphism**: Override methods trong các lớp con
- **Encapsulation**: Properties, validation, access modifiers
- **Abstraction**: Abstract base class, custom exceptions
- **Exception Handling**: Try-catch với 7 custom exceptions
- **Composition**: HeThongQuanLy chứa lists users, rooms, bookings

## 🆘 Gặp Lỗi?

| Lỗi | Giải pháp |
|-----|----------|
| "Sai số điện thoại hoặc mật khẩu!" | Kiểm tra lại SĐT & mật khẩu |
| "SĐT này đã tồn tại!" | Dùng SĐT khác khi đăng ký mới |
| "Phòng không có sẵn!" | Chọn ngày hoặc phòng khác |
| "Không thể xóa phòng" | Phòng đang được đặt, liên hệ quản lý |

## 📚 Tài Liệu Thêm

- **README.md** - Tổng quan dự án
- **KIEN_TRUC_HE_THONG.md** - Sơ đồ lớp, kiến trúc, thiết kế
- **TONG_KET.md** - Tóm tắt hoàn thành

## 💡 Mẹo Sử Dụng

1. **Định dạng ngày**: dd/MM/yyyy (VD: 25/12/2024)
2. **Giá tiền**: Nhập số (VD: 600000)
3. **Mật khẩu**: Hiển thị dấu sao (bảo mật)
4. **Mã phòng**: Phân biệt hoa/thường (P101)
5. **SĐT**: Dùng làm tên đăng nhập, phải duy nhất

---

**Chúc bạn sử dụng vui vẻ! 🎉**
