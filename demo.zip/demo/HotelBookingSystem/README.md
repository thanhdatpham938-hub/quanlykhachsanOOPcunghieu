# Hệ Thống Quản Lý Đặt Phòng Khách Sạn

## 📋 Giới Thiệu

Hệ thống quản lý đặt phòng khách sạn được phát triển bằng C# với **Windows Forms UI** thân thiện và hiện đại, hỗ trợ đầy đủ các chức năng quản lý từ đặt phòng, hủy phòng cho đến báo cáo doanh thu. Giao diện trực quan với các form riêng cho từng chức năng.

## 🏗️ Kiến Trúc Dự Án

```
HotelBookingSystem/
├── Models/
│   ├── Enums.cs              # Các enum (VaiTro, TrangThaiPhong, v.v.)
│   ├── NguoiDung.cs          # Base class - Người dùng
│   ├── DerivedUsers.cs       # KhachHang, NhanVien, QuanLy
│   └── Phong.cs              # Room & Booking classes
├── Controllers/
│   └── HeThongQuanLy.cs      # Main system controller
├── Exceptions/
│   └── HotelExceptions.cs    # Custom exceptions
├── UI/
│   └── GiaoDienConsole.cs    # Console interface
├── Program.cs                # Entry point
└── HotelBookingSystem.csproj # Project file
```

## 🎯 Các Lớp Chính

### 1. **NguoiDung (Base Class)**
- Thuộc tính: HoTen, SoDienThoai, MatKhau, VaiTro, TrangThaiTaiKhoan
- Phương thức: DangNhap(), DangXuat(), DoiMatKhau()

### 2. **KhachHang (Derived)**
- Chức năng: Đặt phòng online, hủy phòng, xem lịch sử, xóa tài khoản
- Lưu lịch sử giao dịch

### 3. **NhanVien (Derived)**
- Chức năng: Đặt phòng offline (tại quầy) cho khách vãng lai
- Xem danh sách đơn đặt

### 4. **QuanLy (Derived)**
- Chức năng: CRUD phòng, quản lý nhân viên, báo cáo doanh thu
- Truy cập tất cả thống kê hệ thống

### 5. **Phong (Room)**
- MaPhong, LoaiPhong (Don/Doi/VIP), GiaTien, TrangThaiHienTai
- Kiểm tra phòng trống trong khoảng thời gian

### 6. **DonDatPhong (Booking)**
- Lưu thông tin đơn đặt: khách, phòng, ngày check-in/out
- Tính toán tổng tiền tự động

## 🔐 Xử Lý Ngoại Lệ

| Exception | Mô Tả |
|-----------|-------|
| `InvalidLoginException` | Sai SĐT hoặc mật khẩu |
| `DuplicateIdException` | SĐT hoặc ID phòng đã tồn tại |
| `RoomUnavailableException` | Phòng không trống trong khoảng thời gian |
| `DataConstraintException` | Vi phạm ràng buộc (vd: xóa phòng đang có khách) |
| `InvalidDataException` | Dữ liệu không hợp lệ |
| `InvalidDateException` | Ngày Check-out < Check-in |
| `ResourceNotFoundException` | Không tìm thấy tài nguyên |

## 🚀 Chạy Ứng Dụng

### Yêu cầu
- .NET 8.0 trở lên
- Windows (vì sử dụng Windows Forms)

### Cách chạy
```bash
# Build dự án
dotnet build

# Chạy ứng dụng
dotnet run
```

Ứng dụng sẽ mở cửa sổ Windows Forms với giao diện chính.

## 📱 Hướng Dẫn Sử Dụng

### Giao Diện Chính

Ứng dụng mở ra với **Form Main** hiển thị 4 nút chính:

1. **Đăng Nhập** - Đăng nhập với tài khoản đã đăng ký
2. **Đăng Ký Tài Khoản** - Tạo tài khoản khách hàng mới
3. **Xem Danh Sách Phòng** - Xem tất cả phòng hiện có
4. **Thoát** - Đóng ứng dụng

### Tài Khoản Mẫu (Test)

| Vai Trò | SĐT | Mật Khẩu |
|---------|-----|---------|
| Quản Lý | 0123456789 | admin123 |
| Nhân Viên | 0987654321 | staff123 |
| Khách Hàng | 0911111111 | customer123 |

### Phòng Mẫu

| Mã Phòng | Loại | Giá |
|----------|------|-----|
| P101, P102 | Đơn | 500.000 VND |
| P201, P202 | Đôi | 800.000 VND |
| P301, P302 | VIP | 1.500.000 VND |

### Menu Khách Hàng (sau khi đăng nhập)

Form **Menu Khách Hàng** với các chức năng:

1. **Đặt Phòng Online**
   - Chọn ngày Check-in/Check-out
   - Hiển thị danh sách phòng trống
   - Chọn phòng và xác nhận

2. **Xem Trạng Thái & Hủy Phòng**
   - Liệt kê các đơn đang đặt
   - Hủy đơn (trong 24 giờ trước Check-in)

3. **Xem Lịch Sử Giao Dịch**
   - Hiển thị toàn bộ lịch sử trong DataGridView
   - Thể hiện trạng thái đơn (Đã Đặt, Đã Hủy, Đã Hoàn Thành)

4. **Thông Tin Tài Khoản**
   - Hiển thị thông tin cá nhân

5. **Xóa Tài Khoản** (Soft Delete)
   - Xóa tài khoản nhưng giữ dữ liệu

### Menu Nhân Viên (sau khi đăng nhập)

Form **Menu Nhân Viên** với các chức năng:

1. **Đặt Phòng Offline (Tại Quầy)**
   - Nhập thông tin khách vãng lai
   - Chọn phòng và tạo đơn

2. **Xem Danh Sách Phòng**
3. **Xem Danh Sách Đơn Đặt**
4. **Thông Tin Tài Khoản**

### Menu Quản Lý (sau khi đăng nhập)

Form **Menu Quản Lý** phân thành 3 phần:

#### Quản Lý Phòng
- Thêm Phòng
- Sửa Thông Tin Phòng
- Xóa Phòng
- Xem Danh Sách Phòng

#### Quản Lý Nhân Viên
- Thêm Nhân Viên
- Xóa Nhân Viên
- Xem Danh Sách Nhân Viên

#### Báo Cáo
- **Báo Cáo Doanh Thu** - Chọn tháng/năm để xem doanh thu

## 🎓 Các Tính Năng OOP

### Kế Thừa (Inheritance)
- Base class `NguoiDung` được kế thừa bởi `KhachHang`, `NhanVien`, `QuanLy`
- Mỗi lớp con có thêm phương thức riêng

### Đa Hình (Polymorphism)
- Phương thức ảo `HienThiThongTin()` được override ở các lớp con
- Phương thức ảo `DangNhap()` có xử lý riêng

### Tính Đóng Gói (Encapsulation)
- Sử dụng properties với get/set
- Validation trong constructor

### Trừu Tượng (Abstraction)
- Base class `NguoiDung` là abstract
- Các ngoại lệ custom được định nghĩa riêng

## 🔍 Kiểm Tra Dữ Liệu

Hệ thống tự động kiểm tra:
- ✓ SĐT không trùng lặp
- ✓ Mật khẩu tối thiểu 6 ký tự
- ✓ Ngày Check-out > Check-in
- ✓ Phòng không trùng lịch
- ✓ Chỉ hủy phòng trong 24 giờ trước Check-in
- ✓ Không xóa phòng đang có khách

## 📊 Ví Dụ Sử Dụng

### Kịch Bản: Khách hàng đặt phòng

1. Đăng ký tài khoản mới
2. Đăng nhập
3. Nhập ngày: 01/12/2024 - 05/12/2024
4. Chọn phòng P201 (Phòng Đôi)
5. Xác nhận đặt (Hoá đơn: 4 đêm × 800.000 = 3.200.000 VND)
6. Xem lịch sử giao dịch

### Kịch Bản: Quản lý kiểm tra doanh thu

1. Đăng nhập quản lý
2. Vào Menu → Báo Cáo Doanh Thu
3. Nhập tháng 12, năm 2024
4. Xem tổng doanh thu từ các đơn đã hoàn thành

## 📝 Ghi Chú

- Xóa tài khoản là **Soft Delete** - dữ liệu không bị xóa vĩnh viễn
- Lịch sử đơn đặt được lưu riêng cho mỗi khách hàng
- Báo cáo doanh thu chỉ tính các đơn **Đã Hoàn Thành**
- Phòng có trạng thái "Đang Bảo Trì" sẽ không được phép đặt

## 🛠️ Công Nghệ

- **Ngôn Ngữ**: C# 12
- **Framework**: .NET 8.0
- **UI**: Windows Forms
- **Encoding**: UTF-8 (Hỗ trợ Tiếng Việt)

## 👨‍💻 Tác Giả

Hệ thống quản lý đặt phòng khách sạn - Demo Project

---

**Version**: 1.0  
**Last Updated**: November 2024
