# 📌 TÓM TẮT DỰ ÁN

## ✅ Hoàn Thành

Hệ thống quản lý đặt phòng khách sạn đầy đủ với:

### 🏛️ Kiến Trúc OOP
- ✓ **Kế Thừa**: Base class `NguoiDung` → `KhachHang`, `NhanVien`, `QuanLy`
- ✓ **Đa Hình**: Override phương thức `HienThiThongTin()`, `DangNhap()`
- ✓ **Tính Đóng Gói**: Properties, validation trong constructor
- ✓ **Trừu Tượng**: Abstract base class, custom exceptions

### 👥 Người Dùng & Vai Trò
- ✓ **KhachHang**: Đặt phòng online, hủy, xem lịch sử, xóa tài khoản
- ✓ **NhanVien**: Đặt phòng offline (tại quầy), xem danh sách
- ✓ **QuanLy**: CRUD phòng, quản lý nhân viên, báo cáo doanh thu

### 🏨 Chức Năng Chính
- ✓ **Đăng Ký/Đăng Nhập**: Validation, xác thực người dùng
- ✓ **Quản Lý Phòng**: Thêm/Sửa/Xóa phòng (CRUD)
- ✓ **Đặt Phòng**: Online (khách hàng) + Offline (nhân viên)
- ✓ **Hủy Phòng**: Kiểm tra ràng buộc 24h
- ✓ **Báo Cáo Doanh Thu**: Lọc theo tháng/năm
- ✓ **Quản Lý Nhân Viên**: Thêm/Xóa nhân viên

### 🛡️ Xử Lý Ngoại Lệ
- ✓ `InvalidLoginException` - Sai thông tin đăng nhập
- ✓ `DuplicateIdException` - SĐT/ID trùng lặp
- ✓ `RoomUnavailableException` - Phòng không trống
- ✓ `DataConstraintException` - Vi phạm ràng buộc
- ✓ `InvalidDataException` - Dữ liệu không hợp lệ
- ✓ `InvalidDateException` - Ngày không hợp lệ
- ✓ `ResourceNotFoundException` - Không tìm thấy tài nguyên

### 💻 Giao Diện
- ✓ Console UI thân thiện với menu đa cấp
- ✓ Hỗ trợ Tiếng Việt (UTF-8)
- ✓ Hiển thị bảng dữ liệu đẹp mắt
- ✓ Input validation tại client
- ✓ Mật khẩu ẩn khi nhập

### 📄 Tài Liệu
- ✓ **README.md** - Hướng dẫn tổng quan
- ✓ **HUONG_DAN_CHI_TIET.md** - Hướng dẫn chi tiết từng chức năng
- ✓ **KIEN_TRUC_HE_THONG.md** - Sơ đồ lớp, luồng xử lý, thiết kế

## 📁 Cấu Trúc Thư Mục

```
HotelBookingSystem/
├── Models/
│   ├── Enums.cs                    # Các enum (VaiTro, TrangThaiPhong...)
│   ├── NguoiDung.cs                # Base class người dùng
│   ├── DerivedUsers.cs             # KhachHang, NhanVien, QuanLy
│   └── Phong.cs                    # Phong (Room) & DonDatPhong (Booking)
├── Controllers/
│   └── HeThongQuanLy.cs            # Main system controller
├── Exceptions/
│   └── HotelExceptions.cs          # Custom exceptions
├── UI/
│   └── GiaoDienConsole.cs          # Console interface
├── Program.cs                      # Entry point
├── HotelBookingSystem.csproj       # Project file
├── README.md                       # Hướng dẫn tổng quan
├── HUONG_DAN_CHI_TIET.md          # Hướng dẫn chi tiết
├── KIEN_TRUC_HE_THONG.md          # Kiến trúc hệ thống
└── .gitignore                      # Git ignore file
```

## 🚀 Cách Sử Dụng

### Build & Run
```bash
cd HotelBookingSystem
dotnet build           # Biên dịch
dotnet run            # Chạy ứng dụng
```

### Tài Khoản Test
| Vai Trò | SĐT | Pass |
|---------|-----|------|
| Quản Lý | 0123456789 | admin123 |
| Nhân Viên | 0987654321 | staff123 |
| Khách Hàng | 0911111111 | customer123 |

## 📊 Số Liệu

- **Classes**: 7 chính (NguoiDung, KhachHang, NhanVien, QuanLy, Phong, DonDatPhong, HeThongQuanLy)
- **Exceptions**: 7 custom exceptions
- **Methods**: 40+ phương thức chính
- **Lines of Code**: ~2500 dòng
- **Enums**: 5 loại
- **Menu Items**: 20+ tùy chọn

## 🎓 OOP Concepts Áp Dụng

| Khái Niệm | Ví Dụ |
|-----------|-------|
| **Inheritance** | NguoiDung → KhachHang, NhanVien, QuanLy |
| **Polymorphism** | Override HienThiThongTin() |
| **Encapsulation** | Properties, validation |
| **Abstraction** | Base class abstract, interfaces qua exceptions |
| **Composition** | HeThongQuanLy chứa List<NguoiDung>, List<Phong>, List<DonDatPhong> |
| **Association** | KhachHang ↔ DonDatPhong, Phong ↔ DonDatPhong |

## 🔐 Tính Năng Bảo Mật

- ✓ SĐT duy nhất (Primary Key)
- ✓ Mật khẩu tối thiểu 6 ký tự
- ✓ Soft Delete (Xóa tài khoản không mất dữ liệu)
- ✓ Access Control (Kiểm tra vai trò)
- ✓ Business Logic Constraints
  - Không thể xóa phòng đang có khách
  - Chỉ hủy phòng trong 24h trước Check-in
  - Phòng bảo trì không thể đặt

## 💾 Lưu Trữ Dữ Liệu

**Hiện tại**: In-Memory (RAM)
- Dữ liệu mất khi tắt ứng dụng
- Tốc độ nhanh, dễ test

**Tiếp theo**: Database
- SQL Server, MySQL, SQLite
- Lưu dữ liệu vĩnh viễn
- Entity Framework Core

## 🎯 Chức Năng Chính - Overview

```
┌─ Đăng Ký/Đăng Nhập
│  ├─ Đăng ký khách hàng mới
│  └─ Đăng nhập với SĐT & mật khẩu
│
├─ Khách Hàng Menu
│  ├─ Đặt phòng online
│  ├─ Xem & hủy phòng
│  ├─ Lịch sử giao dịch
│  ├─ Thông tin tài khoản
│  └─ Xóa tài khoản
│
├─ Nhân Viên Menu
│  ├─ Đặt phòng offline
│  ├─ Xem danh sách phòng
│  └─ Xem danh sách đơn
│
└─ Quản Lý Menu
   ├─ Quản Lý Phòng (CRUD)
   ├─ Quản Lý Nhân Viên (Thêm/Xóa)
   ├─ Báo Cáo Doanh Thu
   └─ Xem Danh Sách
```

## 📈 Quy Mô Dữ Liệu Mẫu

- 3 người dùng mẫu (1 Quản Lý, 1 Nhân Viên, 1 Khách Hàng)
- 6 phòng mẫu (2 Đơn, 2 Đôi, 2 VIP)
- 0 đơn đặt (tạo trong quá trình sử dụng)

## 🔄 Luồng Chính

1. **Đăng ký** → Tạo tài khoản KhachHang mới
2. **Đăng nhập** → Kiểm tra SĐT & mật khẩu
3. **Đặt phòng** → Tìm phòng trống, tạo DonDatPhong
4. **Tính tiền** → Ngày × Giá
5. **Hủy/Hoàn thành** → Cập nhật TrangThaiDon
6. **Báo cáo** → Lọc đơn hoàn thành theo tháng/năm

## ⚠️ Giới Hạn Hiện Tại

- Dữ liệu chỉ lưu trong RAM (mất khi tắt ứng dụng)
- Không có database persistent
- Không có authentication/encryption nâng cao
- UI chỉ là console (không phải GUI)
- Không có multi-user concurrency handling

## 🚀 Tiếp Theo?

1. **Thêm Database** (SQL Server/MySQL/SQLite)
2. **Web API** (ASP.NET Core)
3. **Frontend** (React/Vue.js)
4. **Mobile App** (iOS/Android)
5. **Payment Integration** (Stripe/Vnpay)
6. **Email/SMS Notification**
7. **Analytics Dashboard**

---

**Status**: ✅ Hoàn thành  
**Version**: 1.0  
**Build**: Success  
**Last Updated**: November 2024
