using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormAddRoom : Form
    {
        private HeThongQuanLy heThong;
        private TextBox? txtMaPhong;
        private ComboBox? cmbLoaiPhong;
        private TextBox? txtGiaTien;

        public FormAddRoom(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Thêm Phòng Mới";
            this.Size = new Size(400, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            // Mã Phòng
            Label lblMaPhong = new Label { Text = "Mã Phòng:", Location = new Point(20, 20), AutoSize = true };
            txtMaPhong = new TextBox { Location = new Point(150, 20), Size = new Size(200, 30) };

            // Loại Phòng
            Label lblLoaiPhong = new Label { Text = "Loại Phòng:", Location = new Point(20, 60), AutoSize = true };
            cmbLoaiPhong = new ComboBox { Location = new Point(150, 60), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbLoaiPhong.Items.AddRange(new object[] { "Đơn", "Đôi", "VIP" });
            cmbLoaiPhong.SelectedIndex = 0;

            // Giá Tiền
            Label lblGiaTien = new Label { Text = "Giá Tiền (VND):", Location = new Point(20, 100), AutoSize = true };
            txtGiaTien = new TextBox { Location = new Point(150, 100), Size = new Size(200, 30) };

            // Button Thêm
            Button btnThem = new Button { Text = "Thêm", Location = new Point(150, 160), Size = new Size(90, 40), BackColor = Color.FromArgb(46, 204, 113), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnThem.Click += BtnThem_Click;

            // Button Hủy
            Button btnHuy = new Button { Text = "Hủy", Location = new Point(260, 160), Size = new Size(90, 40), BackColor = Color.FromArgb(149, 165, 166), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnHuy.Click += (s, e) => this.Close();

            panelContent.Controls.AddRange(new Control[] { lblMaPhong, txtMaPhong, lblLoaiPhong, cmbLoaiPhong, lblGiaTien, txtGiaTien, btnThem, btnHuy });
            this.Controls.Add(panelContent);
        }

        private void BtnThem_Click(object? sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaPhong?.Text))
                {
                    MessageBox.Show("Vui lòng nhập mã phòng!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!decimal.TryParse(txtGiaTien?.Text, out decimal giaTien) || giaTien <= 0)
                {
                    MessageBox.Show("Vui lòng nhập giá tiền hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                LoaiPhong loai = (LoaiPhong)(cmbLoaiPhong?.SelectedIndex ?? 0);
                heThong.ThemPhongMoi(txtMaPhong.Text, loai, giaTien);
                MessageBox.Show("Thêm phòng thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
