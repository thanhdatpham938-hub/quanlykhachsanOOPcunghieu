using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public class FormAddStaff : Form
    {
        private HeThongQuanLy heThong;
        private TextBox? txtHoTen;
        private TextBox? txtSDT;
        private TextBox? txtMatKhau;

        public FormAddStaff(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Thêm Nhân Viên";
            this.Size = new Size(400, 280);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            // Họ Tên
            Label lblHoTen = new Label { Text = "Họ Tên:", Location = new Point(20, 20), AutoSize = true };
            txtHoTen = new TextBox { Location = new Point(150, 20), Size = new Size(200, 30) };

            // Số Điện Thoại
            Label lblSDT = new Label { Text = "Số Điện Thoại:", Location = new Point(20, 60), AutoSize = true };
            txtSDT = new TextBox { Location = new Point(150, 60), Size = new Size(200, 30) };

            // Mật Khẩu
            Label lblMatKhau = new Label { Text = "Mật Khẩu:", Location = new Point(20, 100), AutoSize = true };
            txtMatKhau = new TextBox { Location = new Point(150, 100), Size = new Size(200, 30), PasswordChar = '*' };

            // Button Thêm
            Button btnThem = new Button { Text = "Thêm", Location = new Point(150, 160), Size = new Size(90, 40), BackColor = Color.FromArgb(46, 204, 113), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnThem.Click += BtnThem_Click;

            // Button Hủy
            Button btnHuy = new Button { Text = "Hủy", Location = new Point(260, 160), Size = new Size(90, 40), BackColor = Color.FromArgb(149, 165, 166), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnHuy.Click += (s, e) => this.Close();

            panelContent.Controls.AddRange(new Control[] { lblHoTen, txtHoTen, lblSDT, txtSDT, lblMatKhau, txtMatKhau, btnThem, btnHuy });
            this.Controls.Add(panelContent);
        }

        private void BtnThem_Click(object? sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtHoTen?.Text))
                {
                    MessageBox.Show("Vui lòng nhập họ tên!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtSDT?.Text))
                {
                    MessageBox.Show("Vui lòng nhập số điện thoại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMatKhau?.Text) || txtMatKhau.Text.Length < 6)
                {
                    MessageBox.Show("Mật khẩu phải có ít nhất 6 ký tự!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                heThong.ThemNhanVienMoi(txtHoTen.Text, txtSDT.Text, txtMatKhau.Text);
                MessageBox.Show("Thêm nhân viên thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
