using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormAllBookingList : Form
    {
        private HeThongQuanLy heThong;
        private DataGridView? dgvBookings;

        public FormAllBookingList(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            InitializeComponent();
            LoadBookings();
        }

        private void InitializeComponent()
        {
            this.Text = "Danh Sách Đơn Đặt";
            this.Size = new Size(1000, 550);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(155, 89, 182);
            panelHeader.Height = 50;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = "DANH SÁCH ĐƠN ĐẶT PHÒNG";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            dgvBookings = new DataGridView();
            dgvBookings.Dock = DockStyle.Fill;
            dgvBookings.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBookings.ReadOnly = true;
            dgvBookings.AllowUserToAddRows = false;
            dgvBookings.AllowUserToDeleteRows = false;
            dgvBookings.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBookings.BackgroundColor = Color.White;
            dgvBookings.GridColor = Color.LightGray;

            // Thêm cột
            dgvBookings.Columns.Add("MaDon", "Mã Đơn");
            dgvBookings.Columns.Add("Khach", "Khách");
            dgvBookings.Columns.Add("Phong", "Phòng");
            dgvBookings.Columns.Add("CheckIn", "Check-in");
            dgvBookings.Columns.Add("CheckOut", "Check-out");
            dgvBookings.Columns.Add("TongTien", "Tổng Tiền");
            dgvBookings.Columns.Add("TrangThai", "Trạng Thái");

            // Styling
            dgvBookings.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(155, 89, 182);
            dgvBookings.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvBookings.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            dgvBookings.RowTemplate.Height = 30;

            Panel panelBottom = new Panel();
            panelBottom.Height = 50;
            panelBottom.Dock = DockStyle.Bottom;
            panelBottom.Padding = new Padding(10);

            Button btnClose = new Button();
            btnClose.Text = "Đóng";
            btnClose.Location = new Point(panelBottom.Width - 110, 10);
            btnClose.Size = new Size(90, 30);
            btnClose.BackColor = Color.FromArgb(149, 165, 166);
            btnClose.ForeColor = Color.White;
            btnClose.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnClose.Click += (s, e) => this.Close();

            panelBottom.Controls.Add(btnClose);

            this.Controls.Add(dgvBookings);
            this.Controls.Add(panelBottom);
            this.Controls.Add(panelHeader);
        }

        private void LoadBookings()
        {
            try
            {
                var danhSachDon = heThong.LayDanhSachDonDat();

                if (dgvBookings != null)
                {
                    dgvBookings.Rows.Clear();

                    if (danhSachDon.Count == 0)
                    {
                        MessageBox.Show("Chưa có đơn đặt nào trong hệ thống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    foreach (var don in danhSachDon)
                    {
                        string khachHang = don.KhachHang?.HoTen ?? "Khách vãng lai";
                        string phong = don.Phong?.MaPhong ?? "N/A";
                        string checkIn = don.NgayCheckIn.ToString("dd/MM/yyyy");
                        string checkOut = don.NgayCheckOut.ToString("dd/MM/yyyy");
                        string tongTien = don.TongTien.ToString("N0");

                        dgvBookings.Rows.Add(
                            don.MaDon,
                            khachHang,
                            phong,
                            checkIn,
                            checkOut,
                            tongTien + " VND",
                            don.TrangThaiDon.ToString()
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải danh sách: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
