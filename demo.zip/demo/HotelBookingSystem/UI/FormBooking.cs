using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public class FormBooking : Form
    {
        private HeThongQuanLy heThong;
        private DateTimePicker dtpCheckIn;
        private DateTimePicker dtpCheckOut;
        private DataGridView dgvRooms;

        public FormBooking(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.dtpCheckIn = new DateTimePicker();
            this.dtpCheckOut = new DateTimePicker();
            this.dgvRooms = new DataGridView();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Đặt Phòng Online";
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterParent;

            Panel panelSearch = new Panel();
            panelSearch.Height = 80;
            panelSearch.Dock = DockStyle.Top;
            panelSearch.Padding = new Padding(10);

            Label lblCheckIn = new Label { Text = "Check-in:", Location = new Point(10, 10), AutoSize = true };
            dtpCheckIn.Location = new Point(80, 10);
            dtpCheckIn.Size = new Size(150, 25);
            dtpCheckIn.Value = DateTime.Now;

            Label lblCheckOut = new Label { Text = "Check-out:", Location = new Point(250, 10), AutoSize = true };
            dtpCheckOut.Location = new Point(330, 10);
            dtpCheckOut.Size = new Size(150, 25);
            dtpCheckOut.Value = DateTime.Now.AddDays(1);

            Button btnSearch = new Button();
            btnSearch.Text = "Tìm Phòng Trống";
            btnSearch.Location = new Point(500, 10);
            btnSearch.Size = new Size(150, 25);
            btnSearch.BackColor = Color.FromArgb(52, 152, 219);
            btnSearch.ForeColor = Color.White;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.FlatAppearance.BorderSize = 0;
            btnSearch.Click += BtnSearch_Click;

            Button btnBook = new Button();
            btnBook.Text = "Đặt Phòng Được Chọn";
            btnBook.Location = new Point(500, 45);
            btnBook.Size = new Size(150, 25);
            btnBook.BackColor = Color.FromArgb(46, 204, 113);
            btnBook.ForeColor = Color.White;
            btnBook.FlatStyle = FlatStyle.Flat;
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.Click += BtnBook_Click;

            panelSearch.Controls.AddRange(new Control[] { lblCheckIn, dtpCheckIn, lblCheckOut, dtpCheckOut, btnSearch, btnBook });

            dgvRooms.Dock = DockStyle.Fill;
            dgvRooms.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvRooms.ReadOnly = true;
            dgvRooms.AllowUserToAddRows = false;
            dgvRooms.AllowUserToDeleteRows = false;
            dgvRooms.Columns.Add("MaPhong", "Mã Phòng");
            dgvRooms.Columns.Add("LoaiPhong", "Loại Phòng");
            dgvRooms.Columns.Add("GiaTien", "Giá (VND)");

            this.Controls.Add(dgvRooms);
            this.Controls.Add(panelSearch);
        }

        private void BtnSearch_Click(object? sender, EventArgs e)
        {
            var phongTrong = heThong.TimPhongTrong(dtpCheckIn.Value, dtpCheckOut.Value);
            dgvRooms.Rows.Clear();

            foreach (var phong in phongTrong)
            {
                dgvRooms.Rows.Add(phong.MaPhong, phong.LoaiPhong.ToString(), phong.GiaTien.ToString("C0"));
            }

            if (phongTrong.Count == 0)
                MessageBox.Show("Không có phòng trống trong khoảng thời gian này!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnBook_Click(object? sender, EventArgs e)
        {
            if (dgvRooms.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn phòng cần đặt!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maPhong = dgvRooms.SelectedRows[0].Cells[0].Value.ToString() ?? "";
            heThong.DatPhongOnline(dtpCheckIn.Value, dtpCheckOut.Value, maPhong);
            MessageBox.Show("Đặt phòng thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }
}
