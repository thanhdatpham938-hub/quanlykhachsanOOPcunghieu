using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormBookingHistory : Form
    {
        private HeThongQuanLy heThong;
        private DataGridView dgvHistory;
        private KhachHang? khachHang;

        public FormBookingHistory(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.khachHang = heThong.LayNguoiDungDangNhap() as KhachHang;
            this.dgvHistory = new DataGridView();
            InitializeComponent();
            LoadHistory();
        }

        private void InitializeComponent()
        {
            this.Text = "Lịch Sử Giao Dịch";
            this.Size = new Size(900, 500);
            this.StartPosition = FormStartPosition.CenterParent;

            dgvHistory.Dock = DockStyle.Fill;
            dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvHistory.ReadOnly = true;
            dgvHistory.AllowUserToAddRows = false;
            dgvHistory.AllowUserToDeleteRows = false;
            dgvHistory.Columns.Add("MaDon", "Mã Đơn");
            dgvHistory.Columns.Add("Phong", "Phòng");
            dgvHistory.Columns.Add("CheckIn", "Check-in");
            dgvHistory.Columns.Add("CheckOut", "Check-out");
            dgvHistory.Columns.Add("SoNgay", "Số Đêm");
            dgvHistory.Columns.Add("TongTien", "Tổng Tiền");
            dgvHistory.Columns.Add("TrangThai", "Trạng Thái");

            this.Controls.Add(dgvHistory);
        }

        private void LoadHistory()
        {
            dgvHistory.Rows.Clear();
            if (khachHang == null) return;

            foreach (var don in khachHang.LichSuGiaoDich)
            {
                int soNgay = (don.NgayCheckOut - don.NgayCheckIn).Days;
                dgvHistory.Rows.Add(
                    don.MaDon,
                    don.Phong?.MaPhong ?? "N/A",
                    don.NgayCheckIn.ToString("dd/MM/yyyy"),
                    don.NgayCheckOut.ToString("dd/MM/yyyy"),
                    soNgay,
                    don.TongTien.ToString("C0"),
                    don.TrangThaiDon.ToString()
                );
            }
        }
    }
}
