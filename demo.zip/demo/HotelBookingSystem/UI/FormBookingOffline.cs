using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public class FormBookingOffline : Form
    {
        private HeThongQuanLy heThong;
        private TextBox txtName;
        private TextBox txtPhone;
        private DateTimePicker dtpCheckIn;
        private DateTimePicker dtpCheckOut;
        private DataGridView dgvRooms;

        public FormBookingOffline(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.txtName = new TextBox();
            this.txtPhone = new TextBox();
            this.dtpCheckIn = new DateTimePicker();
            this.dtpCheckOut = new DateTimePicker();
            this.dgvRooms = new DataGridView();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Đặt Phòng Offline";
            this.Size = new Size(700, 550);
            this.StartPosition = FormStartPosition.CenterParent;

            Panel panelInfo = new Panel();
            panelInfo.Height = 120;
            panelInfo.Dock = DockStyle.Top;
            panelInfo.Padding = new Padding(10);

            Label lblName = new Label { Text = "Tên Khách:", Location = new Point(10, 10), AutoSize = true };
            txtName.Location = new Point(100, 10);
            txtName.Size = new Size(200, 25);

            Label lblPhone = new Label { Text = "SĐT Khách:", Location = new Point(320, 10), AutoSize = true };
            txtPhone.Location = new Point(420, 10);
            txtPhone.Size = new Size(200, 25);

            Label lblCheckIn = new Label { Text = "Check-in:", Location = new Point(10, 50), AutoSize = true };
            dtpCheckIn.Location = new Point(100, 50);
            dtpCheckIn.Size = new Size(200, 25);
            dtpCheckIn.Value = DateTime.Now;

            Label lblCheckOut = new Label { Text = "Check-out:", Location = new Point(320, 50), AutoSize = true };
            dtpCheckOut.Location = new Point(420, 50);
            dtpCheckOut.Size = new Size(200, 25);
            dtpCheckOut.Value = DateTime.Now.AddDays(1);

            Button btnSearch = new Button();
            btnSearch.Text = "Tìm Phòng";
            btnSearch.Location = new Point(10, 85);
            btnSearch.Size = new Size(120, 25);
            btnSearch.BackColor = Color.FromArgb(52, 152, 219);
            btnSearch.ForeColor = Color.White;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.FlatAppearance.BorderSize = 0;
            btnSearch.Click += BtnSearch_Click;

            Button btnBook = new Button();
            btnBook.Text = "Đặt Phòng";
            btnBook.Location = new Point(140, 85);
            btnBook.Size = new Size(120, 25);
            btnBook.BackColor = Color.FromArgb(46, 204, 113);
            btnBook.ForeColor = Color.White;
            btnBook.FlatStyle = FlatStyle.Flat;
            btnBook.FlatAppearance.BorderSize = 0;
            btnBook.Click += BtnBook_Click;

            panelInfo.Controls.AddRange(new Control[] { lblName, txtName, lblPhone, txtPhone, lblCheckIn, dtpCheckIn, lblCheckOut, dtpCheckOut, btnSearch, btnBook });

            dgvRooms.Dock = DockStyle.Fill;
            dgvRooms.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvRooms.ReadOnly = true;
            dgvRooms.AllowUserToAddRows = false;
            dgvRooms.AllowUserToDeleteRows = false;
            dgvRooms.Columns.Add("MaPhong", "Mã Phòng");
            dgvRooms.Columns.Add("LoaiPhong", "Loại Phòng");
            dgvRooms.Columns.Add("GiaTien", "Giá (VND)");

            this.Controls.Add(dgvRooms);
            this.Controls.Add(panelInfo);
        }

        private void BtnSearch_Click(object? sender, EventArgs e)
        {
            var phongTrong = heThong.TimPhongTrong(dtpCheckIn.Value, dtpCheckOut.Value);
            dgvRooms.Rows.Clear();

            foreach (var phong in phongTrong)
            {
                dgvRooms.Rows.Add(phong.MaPhong, phong.LoaiPhong.ToString(), phong.GiaTien.ToString("C0"));
            }

            if (phongTrong.Count == 0)
                MessageBox.Show("Không có phòng trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnBook_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text) || string.IsNullOrEmpty(txtPhone.Text))
            {
                MessageBox.Show("Vui lòng nhập thông tin khách!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dgvRooms.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn phòng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maPhong = dgvRooms.SelectedRows[0].Cells[0].Value.ToString() ?? "";
            heThong.DatPhongOffline(txtName.Text, txtPhone.Text, maPhong, dtpCheckIn.Value, dtpCheckOut.Value);
            MessageBox.Show("Đặt phòng offline thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }
}
