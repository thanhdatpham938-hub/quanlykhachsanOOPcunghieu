using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormCancelBooking : Form
    {
        private HeThongQuanLy heThong;
        private DataGridView dgvBookings;
        private KhachHang? khachHang;

        public FormCancelBooking(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.khachHang = heThong.LayNguoiDungDangNhap() as KhachHang;
            this.dgvBookings = new DataGridView();
            InitializeComponent();
            LoadBookings();
        }

        private void InitializeComponent()
        {
            this.Text = "Xem & Hủy Đơn Đặt";
            this.Size = new Size(800, 400);
            this.StartPosition = FormStartPosition.CenterParent;

            Panel panelBottom = new Panel();
            panelBottom.Height = 50;
            panelBottom.Dock = DockStyle.Bottom;

            Button btnCancel = new Button();
            btnCancel.Text = "Hủy Đơn Đặt";
            btnCancel.Location = new Point(10, 10);
            btnCancel.Size = new Size(150, 30);
            btnCancel.BackColor = Color.FromArgb(231, 76, 60);
            btnCancel.ForeColor = Color.White;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.Click += BtnCancel_Click;

            Button btnClose = new Button();
            btnClose.Text = "Đóng";
            btnClose.Location = new Point(170, 10);
            btnClose.Size = new Size(150, 30);
            btnClose.BackColor = Color.FromArgb(149, 165, 166);
            btnClose.ForeColor = Color.White;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => this.Close();

            panelBottom.Controls.AddRange(new Control[] { btnCancel, btnClose });

            dgvBookings.Dock = DockStyle.Fill;
            dgvBookings.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBookings.ReadOnly = true;
            dgvBookings.AllowUserToAddRows = false;
            dgvBookings.AllowUserToDeleteRows = false;
            dgvBookings.Columns.Add("MaDon", "Mã Đơn");
            dgvBookings.Columns.Add("Phong", "Phòng");
            dgvBookings.Columns.Add("CheckIn", "Check-in");
            dgvBookings.Columns.Add("CheckOut", "Check-out");
            dgvBookings.Columns.Add("TongTien", "Tổng Tiền");
            dgvBookings.Columns.Add("TrangThai", "Trạng Thái");

            this.Controls.Add(dgvBookings);
            this.Controls.Add(panelBottom);
        }

        private void LoadBookings()
        {
            dgvBookings.Rows.Clear();
            if (khachHang == null) return;

            foreach (var don in khachHang.LichSuGiaoDich)
            {
                if (don.TrangThaiDon == TrangThaiDon.DaDat)
                {
                    dgvBookings.Rows.Add(
                        don.MaDon,
                        don.Phong?.MaPhong ?? "N/A",
                        don.NgayCheckIn.ToString("dd/MM/yyyy"),
                        don.NgayCheckOut.ToString("dd/MM/yyyy"),
                        don.TongTien.ToString("C0"),
                        don.TrangThaiDon.ToString()
                    );
                }
            }
        }

        private void BtnCancel_Click(object? sender, EventArgs e)
        {
            if (dgvBookings.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn đơn cần hủy!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maDon = dgvBookings.SelectedRows[0].Cells[0].Value.ToString() ?? "";
            heThong.HuyDatPhong(maDon);
            MessageBox.Show("Đơn đặt phòng đã bị hủy!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadBookings();
        }
    }
}
