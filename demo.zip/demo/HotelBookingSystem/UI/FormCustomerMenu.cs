using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormCustomerMenu : Form
    {
        private HeThongQuanLy heThong;
        private KhachHang? khachHang;

        public FormCustomerMenu(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.khachHang = heThong.LayNguoiDungDangNhap() as KhachHang;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = khachHang != null ? $"Menu Khách Hàng - {khachHang.HoTen}" : "Menu Khách Hàng";
            this.Size = new Size(500, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(52, 152, 219);
            panelHeader.Height = 60;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = $"MENU KHÁCH HÀNG";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            int btnY = 20;
            int btnHeight = 40;
            int spacing = 15;

            // Nút Đặt Phòng Online
            Button btnBooking = CreateButton("Đặt Phòng Online", 20, btnY, 430);
            btnBooking.Click += (s, e) => new FormBooking(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            // Nút Xem Trạng Thái & Hủy
            Button btnViewCancel = CreateButton("Xem Trạng Thái & Hủy Phòng", 20, btnY, 430);
            btnViewCancel.Click += (s, e) => new FormCancelBooking(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            // Nút Lịch Sử
            Button btnHistory = CreateButton("Xem Lịch Sử Giao Dịch", 20, btnY, 430);
            btnHistory.Click += (s, e) => new FormBookingHistory(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            // Nút Thông Tin Tài Khoản
            Button btnProfile = CreateButton("Thông Tin Tài Khoản", 20, btnY, 430);
            btnProfile.Click += (s, e) => ShowAccountInfo();
            btnY += btnHeight + spacing;

            // Nút Xóa Tài Khoản
            Button btnDelete = CreateButton("Xóa Tài Khoản", 20, btnY, 430);
            btnDelete.BackColor = Color.FromArgb(231, 76, 60);
            btnDelete.Click += (s, e) => DeleteAccount();
            btnY += btnHeight + spacing;

            // Nút Thoát
            Button btnExit = CreateButton("Thoát", 20, btnY, 430);
            btnExit.BackColor = Color.FromArgb(149, 165, 166);
            btnExit.Click += (s, e) => this.Close();

            panelContent.Controls.AddRange(new Control[] { btnBooking, btnViewCancel, btnHistory, btnProfile, btnDelete, btnExit });

            this.Controls.Add(panelContent);
            this.Controls.Add(panelHeader);
        }

        private Button CreateButton(string text, int x, int y, int width)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(width, 40);
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(52, 152, 219);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private void ShowAccountInfo()
        {
            if (khachHang == null) return;
            
            string info = $"Họ Tên: {khachHang.HoTen}\n" +
                         $"Số Điện Thoại: {khachHang.SoDienThoai}\n" +
                         $"Vai Trò: {khachHang.VaiTro}\n" +
                         $"Trạng Thái: {khachHang.TrangThaiTaiKhoan}\n" +
                         $"Số Đơn Đặt: {khachHang.LichSuGiaoDich.Count}";
            
            MessageBox.Show(info, "Thông Tin Tài Khoản", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void DeleteAccount()
        {
            if (khachHang == null) return;

            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn xóa tài khoản? Dữ liệu sẽ được bảo lưu.",
                "Xác Nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                khachHang.XoaTaiKhoan();
                MessageBox.Show("Tài khoản đã được xóa!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
    }
}
