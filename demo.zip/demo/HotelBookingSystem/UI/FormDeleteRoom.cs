using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public class FormDeleteRoom : Form
    {
        private HeThongQuanLy heThong;
        private TextBox? txtMaPhong;

        public FormDeleteRoom(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Xóa Phòng";
            this.Size = new Size(400, 200);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            // Mã Phòng
            Label lblMaPhong = new Label { Text = "Mã Phòng:", Location = new Point(20, 20), AutoSize = true };
            txtMaPhong = new TextBox { Location = new Point(150, 20), Size = new Size(200, 30) };

            Label lblNotice = new Label { Text = "⚠ Chỉ có thể xóa phòng khi chưa có đơn đặt!", Location = new Point(20, 60), AutoSize = true, ForeColor = Color.Red };

            // Button Xóa
            Button btnXoa = new Button { Text = "Xóa", Location = new Point(150, 100), Size = new Size(90, 40), BackColor = Color.FromArgb(231, 76, 60), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnXoa.Click += BtnXoa_Click;

            // Button Hủy
            Button btnHuy = new Button { Text = "Hủy", Location = new Point(260, 100), Size = new Size(90, 40), BackColor = Color.FromArgb(149, 165, 166), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnHuy.Click += (s, e) => this.Close();

            panelContent.Controls.AddRange(new Control[] { lblMaPhong, txtMaPhong, lblNotice, btnXoa, btnHuy });
            this.Controls.Add(panelContent);
        }

        private void BtnXoa_Click(object? sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaPhong?.Text))
                {
                    MessageBox.Show("Vui lòng nhập mã phòng!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("Bạn chắc chắn muốn xóa phòng này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    heThong.XoaPhongKhiSan(txtMaPhong.Text);
                    MessageBox.Show("Xóa phòng thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
