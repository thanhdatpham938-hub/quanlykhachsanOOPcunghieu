using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public class FormDeleteStaff : Form
    {
        private HeThongQuanLy heThong;
        private TextBox? txtSDT;

        public FormDeleteStaff(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Xóa Nhân Viên";
            this.Size = new Size(400, 200);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            // Số Điện Thoại
            Label lblSDT = new Label { Text = "Số Điện Thoại:", Location = new Point(20, 20), AutoSize = true };
            txtSDT = new TextBox { Location = new Point(150, 20), Size = new Size(200, 30) };

            // Button Xóa
            Button btnXoa = new Button { Text = "Xóa", Location = new Point(150, 80), Size = new Size(90, 40), BackColor = Color.FromArgb(231, 76, 60), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnXoa.Click += BtnXoa_Click;

            // Button Hủy
            Button btnHuy = new Button { Text = "Hủy", Location = new Point(260, 80), Size = new Size(90, 40), BackColor = Color.FromArgb(149, 165, 166), ForeColor = Color.White, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            btnHuy.Click += (s, e) => this.Close();

            panelContent.Controls.AddRange(new Control[] { lblSDT, txtSDT, btnXoa, btnHuy });
            this.Controls.Add(panelContent);
        }

        private void BtnXoa_Click(object? sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSDT?.Text))
                {
                    MessageBox.Show("Vui lòng nhập số điện thoại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("Bạn chắc chắn muốn xóa nhân viên này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    heThong.XoaNhanVien(txtSDT.Text);
                    MessageBox.Show("Xóa nhân viên thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
