using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormLogin : Form
    {
        private HeThongQuanLy heThong;
        private TextBox txtPhone;
        private TextBox txtPassword;

        public FormLogin(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.txtPhone = new TextBox();
            this.txtPassword = new TextBox();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Đăng Nhập";
            this.Size = new Size(400, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Panel tiêu đề
            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(52, 152, 219);
            panelHeader.Height = 50;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = "ĐĂNG NHẬP HỆ THỐNG";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            // Panel nội dung
            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            // Số điện thoại
            Label lblPhone = new Label();
            lblPhone.Text = "Số Điện Thoại:";
            lblPhone.Location = new Point(20, 20);
            lblPhone.AutoSize = true;

            txtPhone = new TextBox();
            txtPhone.Location = new Point(20, 45);
            txtPhone.Size = new Size(350, 30);
            txtPhone.Font = new Font("Segoe UI", 11);

            // Mật khẩu
            Label lblPassword = new Label();
            lblPassword.Text = "Mật Khẩu:";
            lblPassword.Location = new Point(20, 85);
            lblPassword.AutoSize = true;

            txtPassword = new TextBox();
            txtPassword.Location = new Point(20, 110);
            txtPassword.Size = new Size(350, 30);
            txtPassword.Font = new Font("Segoe UI", 11);
            txtPassword.PasswordChar = '*';

            // Nút Đăng Nhập
            Button btnLogin = new Button();
            btnLogin.Text = "Đăng Nhập";
            btnLogin.Location = new Point(20, 160);
            btnLogin.Size = new Size(350, 40);
            btnLogin.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            btnLogin.BackColor = Color.FromArgb(52, 152, 219);
            btnLogin.ForeColor = Color.White;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;

            panelContent.Controls.AddRange(new Control[] { lblPhone, txtPhone, lblPassword, txtPassword, btnLogin });

            this.Controls.Add(panelContent);
            this.Controls.Add(panelHeader);
        }

        private void BtnLogin_Click(object? sender, EventArgs e)
        {
            string phone = txtPhone.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (heThong.DangNhap(phone, password))
            {
                var user = heThong.LayNguoiDungDangNhap();
                if (user != null)
                {
                    this.Hide();
                    
                    switch (user.VaiTro)
                    {
                        case VaiTro.KhachHang:
                            new FormCustomerMenu(heThong).ShowDialog();
                            break;
                        case VaiTro.NhanVien:
                            new FormStaffMenu(heThong).ShowDialog();
                            break;
                        case VaiTro.QuanLy:
                            new FormManagerMenu(heThong).ShowDialog();
                            break;
                    }

                    heThong.DangXuat();
                    this.Show();
                    txtPhone.Clear();
                    txtPassword.Clear();
                }
            }
            else
            {
                MessageBox.Show("Đăng nhập thất bại! Kiểm tra lại SĐT hoặc mật khẩu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
