using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public partial class FormMain : Form
    {
        private HeThongQuanLy heThong;

        public FormMain()
        {
            InitializeComponent();
            heThong = new HeThongQuanLy();
        }

        private void InitializeComponent()
        {
            this.Text = "Hệ Thống Quản Lý Đặt Phòng Khách Sạn";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            // Panel tiêu đề
            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(70, 130, 180);
            panelHeader.Height = 80;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = "HỆ THỐNG QUẢN LÝ ĐẶT PHÒNG KHÁCH SẠN";
            lblTitle.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            // Panel chính với FlowLayoutPanel để căn giữa các nút khi mở rộng
            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.BackColor = Color.White;

            FlowLayoutPanel flowPanel = new FlowLayoutPanel();
            flowPanel.Dock = DockStyle.Fill;
            flowPanel.FlowDirection = FlowDirection.TopDown;
            flowPanel.WrapContents = false;
            flowPanel.Padding = new Padding(20);
            flowPanel.AutoScroll = false;

            // Nút Đăng Nhập
            Button btnLogin = new Button();
            btnLogin.Text = "Đăng Nhập";
            btnLogin.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnLogin.Size = new Size(400, 50);
            btnLogin.Margin = new Padding(0, 10, 0, 10);
            btnLogin.BackColor = Color.FromArgb(52, 152, 219);
            btnLogin.ForeColor = Color.White;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;

            // Nút Đăng Ký
            Button btnRegister = new Button();
            btnRegister.Text = "Đăng Ký Tài Khoản";
            btnRegister.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnRegister.Size = new Size(400, 50);
            btnRegister.Margin = new Padding(0, 10, 0, 10);
            btnRegister.BackColor = Color.FromArgb(46, 204, 113);
            btnRegister.ForeColor = Color.White;
            btnRegister.FlatStyle = FlatStyle.Flat;
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.Click += BtnRegister_Click;

            // Nút Xem Danh Sách Phòng
            Button btnViewRooms = new Button();
            btnViewRooms.Text = "Xem Danh Sách Phòng";
            btnViewRooms.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnViewRooms.Size = new Size(400, 50);
            btnViewRooms.Margin = new Padding(0, 10, 0, 10);
            btnViewRooms.BackColor = Color.FromArgb(155, 89, 182);
            btnViewRooms.ForeColor = Color.White;
            btnViewRooms.FlatStyle = FlatStyle.Flat;
            btnViewRooms.FlatAppearance.BorderSize = 0;
            btnViewRooms.Click += BtnViewRooms_Click;

            // Nút Thoát
            Button btnExit = new Button();
            btnExit.Text = "Thoát";
            btnExit.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            btnExit.Size = new Size(400, 50);
            btnExit.Margin = new Padding(0, 10, 0, 10);
            btnExit.BackColor = Color.FromArgb(231, 76, 60);
            btnExit.ForeColor = Color.White;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.Click += (s, e) => Application.Exit();

            flowPanel.Controls.AddRange(new Control[] { btnLogin, btnRegister, btnViewRooms, btnExit });
            panelContent.Controls.Add(flowPanel);

            this.Controls.Add(panelContent);
            this.Controls.Add(panelHeader);
        }

        private void BtnLogin_Click(object? sender, EventArgs e)
        {
            FormLogin formLogin = new FormLogin(heThong);
            formLogin.ShowDialog();
        }

        private void BtnRegister_Click(object? sender, EventArgs e)
        {
            FormRegister formRegister = new FormRegister(heThong);
            formRegister.ShowDialog();
        }

        private void BtnViewRooms_Click(object? sender, EventArgs e)
        {
            FormRoomList formRoomList = new FormRoomList(heThong);
            formRoomList.ShowDialog();
        }
    }
}
