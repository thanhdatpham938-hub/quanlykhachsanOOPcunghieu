using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public class FormManagerMenu : Form
    {
        private HeThongQuanLy heThong;

        public FormManagerMenu(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Menu Quản Lý";
            this.Size = new Size(550, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(155, 89, 182);
            panelHeader.Height = 60;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = "MENU QUẢN LÝ";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            int btnY = 20;
            int btnHeight = 40;
            int spacing = 10;

            // Quản lý Phòng
            Label lblRoom = new Label { Text = "QUẢN LÝ PHÒNG", Font = new Font("Segoe UI", 11, FontStyle.Bold), Location = new Point(20, btnY), AutoSize = true };
            btnY += 30;

            Button btnAddRoom = CreateButton("Thêm Phòng", 20, btnY, 480);
            btnAddRoom.Click += (s, e) => new FormAddRoom(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnEditRoom = CreateButton("Sửa Thông Tin Phòng", 20, btnY, 480);
            btnEditRoom.Click += (s, e) => new FormEditRoom(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnDeleteRoom = CreateButton("Xóa Phòng", 20, btnY, 480);
            btnDeleteRoom.Click += (s, e) => new FormDeleteRoom(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnViewRooms = CreateButton("Xem Danh Sách Phòng", 20, btnY, 480);
            btnViewRooms.Click += (s, e) => new FormRoomList(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            // Quản lý Nhân Viên
            Label lblStaff = new Label { Text = "QUẢN LÝ NHÂN VIÊN", Font = new Font("Segoe UI", 11, FontStyle.Bold), Location = new Point(20, btnY), AutoSize = true };
            btnY += 30;

            Button btnAddStaff = CreateButton("Thêm Nhân Viên", 20, btnY, 480);
            btnAddStaff.Click += (s, e) => new FormAddStaff(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnDeleteStaff = CreateButton("Xóa Nhân Viên", 20, btnY, 480);
            btnDeleteStaff.Click += (s, e) => new FormDeleteStaff(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnViewStaff = CreateButton("Xem Danh Sách Nhân Viên", 20, btnY, 480);
            btnViewStaff.Click += (s, e) => new FormStaffList(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            // Báo Cáo
            Label lblReport = new Label { Text = "BÁO CÁO", Font = new Font("Segoe UI", 11, FontStyle.Bold), Location = new Point(20, btnY), AutoSize = true };
            btnY += 30;

            Button btnRevenue = CreateButton("Báo Cáo Doanh Thu", 20, btnY, 480);
            btnRevenue.Click += (s, e) => new FormRevenueReport(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnExit = CreateButton("Thoát", 20, btnY, 480);
            btnExit.BackColor = Color.FromArgb(149, 165, 166);
            btnExit.Click += (s, e) => this.Close();

            panelContent.Controls.AddRange(new Control[] 
            { 
                lblRoom, btnAddRoom, btnEditRoom, btnDeleteRoom, btnViewRooms,
                lblStaff, btnAddStaff, btnDeleteStaff, btnViewStaff,
                lblReport, btnRevenue,
                btnExit
            });

            this.Controls.Add(panelContent);
            this.Controls.Add(panelHeader);
        }

        private Button CreateButton(string text, int x, int y, int width)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(width, 40);
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(155, 89, 182);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }
    }
}
