using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormRegister : Form
    {
        private HeThongQuanLy heThong;
        private TextBox txtName;
        private TextBox txtPhone;
        private TextBox txtPassword;
        private TextBox txtConfirmPassword;

        public FormRegister(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.txtName = new TextBox();
            this.txtPhone = new TextBox();
            this.txtPassword = new TextBox();
            this.txtConfirmPassword = new TextBox();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Đăng Ký Tài Khoản";
            this.Size = new Size(450, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(46, 204, 113);
            panelHeader.Height = 50;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = "ĐĂNG KÝ TÀI KHOẢN KHÁCH HÀNG";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            Label lblName = new Label { Text = "Họ Tên:", Location = new Point(20, 20), AutoSize = true };
            txtName.Location = new Point(20, 45);
            txtName.Size = new Size(380, 30);
            txtName.Font = new Font("Segoe UI", 11);

            Label lblPhone = new Label { Text = "Số Điện Thoại:", Location = new Point(20, 80), AutoSize = true };
            txtPhone.Location = new Point(20, 105);
            txtPhone.Size = new Size(380, 30);
            txtPhone.Font = new Font("Segoe UI", 11);

            Label lblPassword = new Label { Text = "Mật Khẩu:", Location = new Point(20, 140), AutoSize = true };
            txtPassword.Location = new Point(20, 165);
            txtPassword.Size = new Size(380, 30);
            txtPassword.Font = new Font("Segoe UI", 11);
            txtPassword.PasswordChar = '*';

            Label lblConfirmPassword = new Label { Text = "Xác Nhận Mật Khẩu:", Location = new Point(20, 200), AutoSize = true };
            txtConfirmPassword.Location = new Point(20, 225);
            txtConfirmPassword.Size = new Size(380, 30);
            txtConfirmPassword.Font = new Font("Segoe UI", 11);
            txtConfirmPassword.PasswordChar = '*';

            Button btnRegister = new Button();
            btnRegister.Text = "Đăng Ký";
            btnRegister.Location = new Point(20, 280);
            btnRegister.Size = new Size(380, 40);
            btnRegister.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            btnRegister.BackColor = Color.FromArgb(46, 204, 113);
            btnRegister.ForeColor = Color.White;
            btnRegister.FlatStyle = FlatStyle.Flat;
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.Click += BtnRegister_Click;

            panelContent.Controls.AddRange(new Control[] 
            { 
                lblName, txtName, lblPhone, txtPhone, 
                lblPassword, txtPassword, lblConfirmPassword, txtConfirmPassword,
                btnRegister
            });

            this.Controls.Add(panelContent);
            this.Controls.Add(panelHeader);
        }

        private void BtnRegister_Click(object? sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(phone) || 
                string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Mật khẩu xác nhận không khớp!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var (success, message) = heThong.DangKy(name, phone, password);
            
            if (success)
            {
                MessageBox.Show(message, "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show(message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
