using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;

namespace HotelBookingSystem.UI
{
    public class FormRevenueReport : Form
    {
        private HeThongQuanLy heThong;
        private NumericUpDown nudMonth;
        private NumericUpDown nudYear;
        private TextBox txtRevenue;

        public FormRevenueReport(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.nudMonth = new NumericUpDown();
            this.nudYear = new NumericUpDown();
            this.txtRevenue = new TextBox();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Báo Cáo Doanh Thu";
            this.Size = new Size(600, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelSearch = new Panel();
            panelSearch.Height = 100;
            panelSearch.Dock = DockStyle.Top;
            panelSearch.Padding = new Padding(20);

            Label lblMonth = new Label { Text = "Tháng:", Location = new Point(20, 20), AutoSize = true };
            nudMonth.Location = new Point(80, 20);
            nudMonth.Size = new Size(100, 25);
            nudMonth.Minimum = 1;
            nudMonth.Maximum = 12;
            nudMonth.Value = DateTime.Now.Month;

            Label lblYear = new Label { Text = "Năm:", Location = new Point(200, 20), AutoSize = true };
            nudYear.Location = new Point(250, 20);
            nudYear.Size = new Size(100, 25);
            nudYear.Minimum = 2020;
            nudYear.Maximum = 2099;
            nudYear.Value = DateTime.Now.Year;

            Button btnSearch = new Button();
            btnSearch.Text = "Xem Báo Cáo";
            btnSearch.Location = new Point(370, 20);
            btnSearch.Size = new Size(150, 25);
            btnSearch.BackColor = Color.FromArgb(46, 204, 113);
            btnSearch.ForeColor = Color.White;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.FlatAppearance.BorderSize = 0;
            btnSearch.Click += BtnSearch_Click;

            panelSearch.Controls.AddRange(new Control[] { lblMonth, nudMonth, lblYear, nudYear, btnSearch });

            Label lblRevenue = new Label { Text = "Kết Quả:", AutoSize = true, Location = new Point(20, 80) };
            panelSearch.Controls.Add(lblRevenue);

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            Label lblResult = new Label { Text = "Doanh Thu Chi Tiết:", AutoSize = true, Location = new Point(20, 20), Font = new Font("Segoe UI", 11, FontStyle.Bold) };

            txtRevenue.Dock = DockStyle.Fill;
            txtRevenue.Multiline = true;
            txtRevenue.ReadOnly = true;
            txtRevenue.ScrollBars = ScrollBars.Vertical;
            txtRevenue.Font = new Font("Courier New", 10);

            panelContent.Controls.Add(txtRevenue);

            this.Controls.Add(panelContent);
            this.Controls.Add(panelSearch);
        }

        private void BtnSearch_Click(object? sender, EventArgs e)
        {
            int thang = (int)nudMonth.Value;
            int nam = (int)nudYear.Value;

            txtRevenue.Clear();
            txtRevenue.AppendText($"Báo Cáo Doanh Thu Tháng {thang}/{nam}\n");
            txtRevenue.AppendText("═════════════════════════════════════\n\n");

            // Gọi phương thức tạo báo cáo dạng chuỗi và hiển thị trong TextBox
            try
            {
                var report = heThong.TaoBaoCaoDoanhThu(thang, nam, includePending: true);
                txtRevenue.AppendText(report);
                txtRevenue.AppendText("\nGhi chú: Báo cáo đang bao gồm cả đơn 'Đã Đặt' và 'Đã Hoàn Thành'.");
            }
            catch (Exception ex)
            {
                txtRevenue.AppendText($"Lỗi khi tạo báo cáo: {ex.Message}");
            }
        }
    }
}
