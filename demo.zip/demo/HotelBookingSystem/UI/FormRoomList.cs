using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormRoomList : Form
    {
        private HeThongQuanLy heThong;
        private DataGridView dgvRooms;

        public FormRoomList(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.dgvRooms = new DataGridView();
            InitializeComponent();
            LoadRooms();
        }

        private void InitializeComponent()
        {
            this.Text = "Danh Sách Phòng";
            this.Size = new Size(600, 400);
            this.StartPosition = FormStartPosition.CenterParent;

            dgvRooms.Dock = DockStyle.Fill;
            dgvRooms.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvRooms.ReadOnly = true;
            dgvRooms.AllowUserToAddRows = false;
            dgvRooms.AllowUserToDeleteRows = false;

            dgvRooms.Columns.Add("MaPhong", "Mã Phòng");
            dgvRooms.Columns.Add("LoaiPhong", "Loại Phòng");
            dgvRooms.Columns.Add("GiaTien", "Giá (VND)");
            dgvRooms.Columns.Add("TrangThaiHienTai", "Trạng Thái");

            this.Controls.Add(dgvRooms);
        }

        private void LoadRooms()
        {
            dgvRooms.Rows.Clear();
            // Lấy thông tin phòng động từ controller
            var danhSach = heThong.LayDanhSachPhong();
            foreach (var p in danhSach)
            {
                dgvRooms.Rows.Add(
                    p.MaPhong,
                    p.LoaiPhong.ToString(),
                    p.GiaTien.ToString("N0"),
                    p.TrangThaiHienTai.ToString()
                );
            }
        }
    }
}
