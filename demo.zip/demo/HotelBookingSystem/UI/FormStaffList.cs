using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormStaffList : Form
    {
        private HeThongQuanLy heThong;
        private DataGridView? dgvStaff;

        public FormStaffList(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            InitializeComponent();
            LoadStaffData();
        }

        private void InitializeComponent()
        {
            this.Text = "Danh Sách Nhân Viên";
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(52, 152, 219);
            panelHeader.Height = 50;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = "DANH SÁCH NHÂN VIÊN";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            dgvStaff = new DataGridView();
            dgvStaff.Dock = DockStyle.Fill;
            dgvStaff.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvStaff.ReadOnly = true;
            dgvStaff.AllowUserToAddRows = false;
            dgvStaff.AllowUserToDeleteRows = false;
            dgvStaff.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStaff.BackgroundColor = Color.White;
            dgvStaff.GridColor = Color.LightGray;

            // Thiết lập cột
            dgvStaff.Columns.Add("HoTen", "Họ Tên");
            dgvStaff.Columns.Add("SoDienThoai", "Số Điện Thoại");
            dgvStaff.Columns.Add("TrangThaiTaiKhoan", "Trạng Thái");

            // Styling
            dgvStaff.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(52, 152, 219);
            dgvStaff.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvStaff.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            dgvStaff.RowTemplate.Height = 30;

            Panel panelBottom = new Panel();
            panelBottom.Height = 50;
            panelBottom.Dock = DockStyle.Bottom;
            panelBottom.Padding = new Padding(10);

            Button btnClose = new Button();
            btnClose.Text = "Đóng";
            btnClose.Location = new Point(panelBottom.Width - 110, 10);
            btnClose.Size = new Size(90, 30);
            btnClose.BackColor = Color.FromArgb(149, 165, 166);
            btnClose.ForeColor = Color.White;
            btnClose.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnClose.Click += (s, e) => this.Close();

            panelBottom.Controls.Add(btnClose);

            this.Controls.Add(dgvStaff);
            this.Controls.Add(panelBottom);
            this.Controls.Add(panelHeader);
        }

        private void LoadStaffData()
        {
            try
            {
                var nguoiDungDangNhap = heThong.LayNguoiDungDangNhap();
                
                if (nguoiDungDangNhap == null || !(nguoiDungDangNhap is QuanLy))
                {
                    MessageBox.Show("Bạn phải đăng nhập là quản lý để xem danh sách nhân viên!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.Close();
                    return;
                }

                // Lấy danh sách nhân viên từ hệ thống
                var danhSachNhanVien = heThong.LayDanhSachNhanVien();

                if (dgvStaff != null)
                {
                    dgvStaff.Rows.Clear();

                    if (danhSachNhanVien.Count == 0)
                    {
                        MessageBox.Show("Chưa có nhân viên nào trong hệ thống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    foreach (var nhanVien in danhSachNhanVien)
                    {
                        dgvStaff.Rows.Add(
                            nhanVien.HoTen,
                            nhanVien.SoDienThoai,
                            nhanVien.TrangThaiTaiKhoan
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải danh sách: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
