using System;
using System.Windows.Forms;
using System.Drawing;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    public class FormStaffMenu : Form
    {
        private HeThongQuanLy heThong;
        private NhanVien? nhanVien;

        public FormStaffMenu(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
            this.nhanVien = heThong.LayNguoiDungDangNhap() as NhanVien;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = nhanVien != null ? $"Menu Nhân Viên - {nhanVien.HoTen}" : "Menu Nhân Viên";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Panel panelHeader = new Panel();
            panelHeader.BackColor = Color.FromArgb(241, 196, 15);
            panelHeader.Height = 60;
            panelHeader.Dock = DockStyle.Top;

            Label lblTitle = new Label();
            lblTitle.Text = "MENU NHÂN VIÊN";
            lblTitle.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Fill;
            panelHeader.Controls.Add(lblTitle);

            Panel panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.Padding = new Padding(20);

            int btnY = 20;
            int btnHeight = 40;
            int spacing = 15;

            Button btnBookOffline = CreateButton("Đặt Phòng Offline (Tại Quầy)", 20, btnY, 430);
            btnBookOffline.Click += (s, e) => new FormBookingOffline(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnRoomList = CreateButton("Xem Danh Sách Phòng", 20, btnY, 430);
            btnRoomList.Click += (s, e) => new FormRoomList(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnBookingList = CreateButton("Xem Danh Sách Đơn Đặt", 20, btnY, 430);
            btnBookingList.Click += (s, e) => new FormAllBookingList(heThong).ShowDialog();
            btnY += btnHeight + spacing;

            Button btnProfile = CreateButton("Thông Tin Tài Khoản", 20, btnY, 430);
            btnProfile.Click += (s, e) => ShowAccountInfo();
            btnY += btnHeight + spacing;

            Button btnExit = CreateButton("Thoát", 20, btnY, 430);
            btnExit.BackColor = Color.FromArgb(149, 165, 166);
            btnExit.Click += (s, e) => this.Close();

            panelContent.Controls.AddRange(new Control[] { btnBookOffline, btnRoomList, btnBookingList, btnProfile, btnExit });

            this.Controls.Add(panelContent);
            this.Controls.Add(panelHeader);
        }

        private Button CreateButton(string text, int x, int y, int width)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(width, 40);
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(241, 196, 15);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private void ShowAccountInfo()
        {
            if (nhanVien == null) return;
            
            string info = $"Họ Tên: {nhanVien.HoTen}\n" +
                         $"Số Điện Thoại: {nhanVien.SoDienThoai}\n" +
                         $"Vai Trò: {nhanVien.VaiTro}\n" +
                         $"Trạng Thái: {nhanVien.TrangThaiTaiKhoan}";
            
            MessageBox.Show(info, "Thông Tin Tài Khoản", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
