using System;
using System.Linq;
using HotelBookingSystem.Controllers;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.UI
{
    /// <summary>
    /// Lớp quản lý giao diện người dùng Console
    /// </summary>
    public class GiaoDienConsole
    {
        private HeThongQuanLy heThong;

        public GiaoDienConsole(HeThongQuanLy heThong)
        {
            this.heThong = heThong;
        }

        /// <summary>
        /// Menu chính - Trước khi đăng nhập
        /// </summary>
        public void MenuChinh()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("╔══════════════════════════════════════════════════════╗");
                Console.WriteLine("║     HỆ THỐNG QUẢN LÝ ĐẶT PHÒNG KHÁCH SẠN            ║");
                Console.WriteLine("╚══════════════════════════════════════════════════════╝");
                Console.WriteLine("\n┌── MENU CHÍNH ──────────────────────────────────────┐");
                Console.WriteLine("│ 1. Đăng Nhập                                        │");
                Console.WriteLine("│ 2. Đăng Ký Tài Khoản Khách Hàng                    │");
                Console.WriteLine("│ 3. Xem Danh Sách Phòng                             │");
                Console.WriteLine("│ 0. Thoát                                            │");
                Console.WriteLine("└─────────────────────────────────────────────────────┘");
                Console.Write("Chọn lựa của bạn: ");

                string luaChon = Console.ReadLine() ?? "";

                switch (luaChon)
                {
                    case "1":
                        DangNhap();
                        break;
                    case "2":
                        DangKy();
                        break;
                    case "3":
                        heThong.HienThiDanhSachPhong();
                        PressAnyKey();
                        break;
                    case "0":
                        Console.WriteLine("✓ Cảm ơn bạn đã sử dụng dịch vụ!");
                        return;
                    default:
                        Console.WriteLine("✗ Lựa chọn không hợp lệ!");
                        PressAnyKey();
                        break;
                }
            }
        }

        /// <summary>
        /// Đăng nhập
        /// </summary>
        private void DangNhap()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║                   ĐĂNG NHẬP                       ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.Write("Nhập số điện thoại: ");
            string sdt = Console.ReadLine() ?? "";

            Console.Write("Nhập mật khẩu: ");
            string matKhau = Doc_PasswordKhongHienThi();

            if (heThong.DangNhap(sdt, matKhau))
            {
                var nguoiDung = heThong.LayNguoiDungDangNhap();
                if (nguoiDung != null)
                {
                    PressAnyKey();

                    // Chuyển đến menu tương ứng với vai trò
                    switch (nguoiDung.VaiTro)
                    {
                        case VaiTro.KhachHang:
                            MenuKhachHang();
                            break;
                        case VaiTro.NhanVien:
                            MenuNhanVien();
                            break;
                        case VaiTro.QuanLy:
                            MenuQuanLy();
                            break;
                    }

                    heThong.DangXuat();
                }
            }
            else
            {
                PressAnyKey();
            }
        }

        /// <summary>
        /// Đăng ký tài khoản
        /// </summary>
        private void DangKy()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║              ĐĂNG KÝ TÀI KHOẢN KHÁCH             ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.Write("Nhập họ tên: ");
            string hoTen = Console.ReadLine() ?? "";

            Console.Write("Nhập số điện thoại: ");
            string sdt = Console.ReadLine() ?? "";

            Console.Write("Nhập mật khẩu (tối thiểu 6 ký tự): ");
            string matKhau = Doc_PasswordKhongHienThi();

            Console.Write("Xác nhận mật khẩu: ");
            string xacNhanMatKhau = Doc_PasswordKhongHienThi();

            if (matKhau != xacNhanMatKhau)
            {
                Console.WriteLine("✗ Mật khẩu xác nhận không khớp!");
                PressAnyKey();
                return;
            }

            heThong.DangKy(hoTen, sdt, matKhau);
            PressAnyKey();
        }

        /// <summary>
        /// Menu dành cho Khách Hàng
        /// </summary>
        private void MenuKhachHang()
        {
            while (true)
            {
                var khach = heThong.LayNguoiDungDangNhap() as KhachHang;
                if (khach == null) break;

                Console.Clear();
                Console.WriteLine($"╔══════════════════════════════════════════════════════╗");
                Console.WriteLine($"║   MENU KHÁCH HÀNG - Chào mừng {khach.HoTen,-26}║");
                Console.WriteLine($"╚══════════════════════════════════════════════════════╝");
                Console.WriteLine("\n┌── CHỨC NĂNG ───────────────────────────────────────┐");
                Console.WriteLine("│ 1. Đặt Phòng Online                                 │");
                Console.WriteLine("│ 2. Xem Trạng Thái & Hủy Phòng                      │");
                Console.WriteLine("│ 3. Xem Lịch Sử Giao Dịch                           │");
                Console.WriteLine("│ 4. Xem Thông Tin Tài Khoản                         │");
                Console.WriteLine("│ 5. Xóa Tài Khoản                                    │");
                Console.WriteLine("│ 0. Đăng Xuất                                        │");
                Console.WriteLine("└─────────────────────────────────────────────────────┘");
                Console.Write("Chọn lựa của bạn: ");

                string luaChon = Console.ReadLine() ?? "";

                switch (luaChon)
                {
                    case "1":
                        DatPhongOnline();
                        break;
                    case "2":
                        HuyDatPhong();
                        break;
                    case "3":
                        heThong.XemLichSuDatPhong();
                        PressAnyKey();
                        break;
                    case "4":
                        khach.HienThiThongTin();
                        PressAnyKey();
                        break;
                    case "5":
                        XoaTaiKhoan();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("✗ Lựa chọn không hợp lệ!");
                        PressAnyKey();
                        break;
                }
            }
        }

        /// <summary>
        /// Đặt phòng online
        /// </summary>
        private void DatPhongOnline()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║            ĐẶT PHÒNG ONLINE                       ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            try
            {
                Console.Write("Nhập ngày Check-in (dd/MM/yyyy): ");
                DateTime checkIn = DateTime.ParseExact(Console.ReadLine() ?? "", "dd/MM/yyyy", null);

                Console.Write("Nhập ngày Check-out (dd/MM/yyyy): ");
                DateTime checkOut = DateTime.ParseExact(Console.ReadLine() ?? "", "dd/MM/yyyy", null);

                // Tìm phòng trống
                var phongTrong = heThong.TimPhongTrong(checkIn, checkOut);

                if (phongTrong.Count == 0)
                {
                    Console.WriteLine("✗ Không có phòng trống trong khoảng thời gian này!");
                    PressAnyKey();
                    return;
                }

                Console.WriteLine("\n=== DANH SÁCH PHÒNG TRỐNG ===");
                Console.WriteLine("┌───────┬──────────┬──────────────┐");
                Console.WriteLine("│ STT   │ Mã Phòng │   Giá (VND)  │");
                Console.WriteLine("├───────┼──────────┼──────────────┤");

                for (int i = 0; i < phongTrong.Count; i++)
                {
                    Console.WriteLine($"│ {i + 1,-5} │ {phongTrong[i].MaPhong,-8} │ {phongTrong[i].GiaTien,12:C0} │");
                }

                Console.WriteLine("└───────┴──────────┴──────────────┘");

                Console.Write("Chọn phòng (nhập mã phòng): ");
                string maPhong = Console.ReadLine() ?? "";

                if (!phongTrong.Any(p => p.MaPhong == maPhong))
                {
                    Console.WriteLine("✗ Phòng không hợp lệ!");
                    PressAnyKey();
                    return;
                }

                heThong.DatPhongOnline(checkIn, checkOut, maPhong);
                PressAnyKey();
            }
            catch (FormatException)
            {
                Console.WriteLine("✗ Định dạng ngày không đúng!");
                PressAnyKey();
            }
        }

        /// <summary>
        /// Hủy đơn đặt phòng
        /// </summary>
        private void HuyDatPhong()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║          HỦY ĐƠN ĐẶT PHÒNG                       ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            heThong.XemLichSuDatPhong();

            Console.Write("\nNhập mã đơn cần hủy: ");
            string maDon = Console.ReadLine() ?? "";

            heThong.HuyDatPhong(maDon);
            PressAnyKey();
        }

        /// <summary>
        /// Xóa tài khoản
        /// </summary>
        private void XoaTaiKhoan()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║           XÓA TÀI KHOẢN                          ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.WriteLine("⚠ Bạn có chắc chắn muốn xóa tài khoản này?");
            Console.WriteLine("(Dữ liệu sẽ được bảo lưu cho báo cáo doanh thu)");
            Console.Write("Nhập 'Yes' để xác nhận: ");

            if (Console.ReadLine()?.ToUpper() == "YES")
            {
                var khach = heThong.LayNguoiDungDangNhap() as KhachHang;
                if (khach != null)
                {
                    khach.XoaTaiKhoan();
                    Console.WriteLine("✓ Tài khoản đã được xóa!");
                    PressAnyKey();
                    return;
                }
            }

            Console.WriteLine("✗ Hủy xóa tài khoản!");
            PressAnyKey();
        }

        /// <summary>
        /// Menu dành cho Nhân Viên
        /// </summary>
        private void MenuNhanVien()
        {
            while (true)
            {
                var nhanVien = heThong.LayNguoiDungDangNhap() as NhanVien;
                if (nhanVien == null) break;

                Console.Clear();
                Console.WriteLine($"╔══════════════════════════════════════════════════════╗");
                Console.WriteLine($"║   MENU NHÂN VIÊN - Chào mừng {nhanVien.HoTen,-27}║");
                Console.WriteLine($"╚══════════════════════════════════════════════════════╝");
                Console.WriteLine("\n┌── CHỨC NĂNG ───────────────────────────────────────┐");
                Console.WriteLine("│ 1. Đặt Phòng Offline (Tại Quầy)                    │");
                Console.WriteLine("│ 2. Xem Danh Sách Phòng                             │");
                Console.WriteLine("│ 3. Xem Danh Sách Đơn Đặt                          │");
                Console.WriteLine("│ 4. Xem Thông Tin Tài Khoản                        │");
                Console.WriteLine("│ 0. Đăng Xuất                                        │");
                Console.WriteLine("└─────────────────────────────────────────────────────┘");
                Console.Write("Chọn lựa của bạn: ");

                string luaChon = Console.ReadLine() ?? "";

                switch (luaChon)
                {
                    case "1":
                        DatPhongOffline();
                        break;
                    case "2":
                        heThong.HienThiDanhSachPhong();
                        PressAnyKey();
                        break;
                    case "3":
                        heThong.HienThiDanhSachDonDat();
                        PressAnyKey();
                        break;
                    case "4":
                        nhanVien.HienThiThongTin();
                        PressAnyKey();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("✗ Lựa chọn không hợp lệ!");
                        PressAnyKey();
                        break;
                }
            }
        }

        /// <summary>
        /// Đặt phòng offline
        /// </summary>
        private void DatPhongOffline()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║            ĐẶT PHÒNG OFFLINE (TẠI QUẦY)         ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            try
            {
                Console.Write("Nhập tên khách vãng lai: ");
                string tenKhach = Console.ReadLine() ?? "";

                Console.Write("Nhập số điện thoại khách: ");
                string sdtKhach = Console.ReadLine() ?? "";

                Console.Write("Nhập ngày Check-in (dd/MM/yyyy): ");
                DateTime checkIn = DateTime.ParseExact(Console.ReadLine() ?? "", "dd/MM/yyyy", null);

                Console.Write("Nhập ngày Check-out (dd/MM/yyyy): ");
                DateTime checkOut = DateTime.ParseExact(Console.ReadLine() ?? "", "dd/MM/yyyy", null);

                // Tìm phòng trống
                var phongTrong = heThong.TimPhongTrong(checkIn, checkOut);

                if (phongTrong.Count == 0)
                {
                    Console.WriteLine("✗ Không có phòng trống trong khoảng thời gian này!");
                    PressAnyKey();
                    return;
                }

                Console.WriteLine("\n=== DANH SÁCH PHÒNG TRỐNG ===");
                Console.WriteLine("┌───────┬──────────┬──────────────┐");
                Console.WriteLine("│ STT   │ Mã Phòng │   Giá (VND)  │");
                Console.WriteLine("├───────┼──────────┼──────────────┤");

                for (int i = 0; i < phongTrong.Count; i++)
                {
                    Console.WriteLine($"│ {i + 1,-5} │ {phongTrong[i].MaPhong,-8} │ {phongTrong[i].GiaTien,12:C0} │");
                }

                Console.WriteLine("└───────┴──────────┴──────────────┘");

                Console.Write("Chọn phòng (nhập mã phòng): ");
                string maPhong = Console.ReadLine() ?? "";

                if (!phongTrong.Any(p => p.MaPhong == maPhong))
                {
                    Console.WriteLine("✗ Phòng không hợp lệ!");
                    PressAnyKey();
                    return;
                }

                heThong.DatPhongOffline(tenKhach, sdtKhach, maPhong, checkIn, checkOut);
                PressAnyKey();
            }
            catch (FormatException)
            {
                Console.WriteLine("✗ Định dạng ngày không đúng!");
                PressAnyKey();
            }
        }

        /// <summary>
        /// Menu dành cho Quản Lý
        /// </summary>
        private void MenuQuanLy()
        {
            while (true)
            {
                var quanLy = heThong.LayNguoiDungDangNhap() as QuanLy;
                if (quanLy == null) break;

                Console.Clear();
                Console.WriteLine($"╔══════════════════════════════════════════════════════╗");
                Console.WriteLine($"║    MENU QUẢN LÝ - Chào mừng {quanLy.HoTen,-28}║");
                Console.WriteLine($"╚══════════════════════════════════════════════════════╝");
                Console.WriteLine("\n┌── QUẢN LÝ PHÒNG ───────────────────────────────────┐");
                Console.WriteLine("│ 1. Thêm Phòng                                       │");
                Console.WriteLine("│ 2. Sửa Thông Tin Phòng                             │");
                Console.WriteLine("│ 3. Xóa Phòng                                        │");
                Console.WriteLine("│ 4. Xem Danh Sách Phòng                             │");
                Console.WriteLine("├─────────────────────────────────────────────────────┤");
                Console.WriteLine("│ 5. Thêm Nhân Viên                                   │");
                Console.WriteLine("│ 6. Xóa Nhân Viên                                    │");
                Console.WriteLine("│ 7. Xem Danh Sách Nhân Viên                         │");
                Console.WriteLine("├─────────────────────────────────────────────────────┤");
                Console.WriteLine("│ 8. Xem Báo Cáo Doanh Thu                           │");
                Console.WriteLine("│ 9. Xem Thông Tin Tài Khoản                        │");
                Console.WriteLine("│ 0. Đăng Xuất                                        │");
                Console.WriteLine("└─────────────────────────────────────────────────────┘");
                Console.Write("Chọn lựa của bạn: ");

                string luaChon = Console.ReadLine() ?? "";

                switch (luaChon)
                {
                    case "1":
                        ThemPhongMoi();
                        break;
                    case "2":
                        SuaPhong();
                        break;
                    case "3":
                        XoaPhong();
                        break;
                    case "4":
                        heThong.HienThiDanhSachPhong();
                        PressAnyKey();
                        break;
                    case "5":
                        ThemNhanVien();
                        break;
                    case "6":
                        XoaNhanVien();
                        break;
                    case "7":
                        heThong.HienThiDanhSachNhanVien();
                        PressAnyKey();
                        break;
                    case "8":
                        XemBaoCaoDoanhThu();
                        break;
                    case "9":
                        quanLy.HienThiThongTin();
                        PressAnyKey();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("✗ Lựa chọn không hợp lệ!");
                        PressAnyKey();
                        break;
                }
            }
        }

        /// <summary>
        /// Thêm phòng mới
        /// </summary>
        private void ThemPhongMoi()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║             THÊM PHÒNG MỚI                        ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.Write("Nhập mã phòng: ");
            string maPhong = Console.ReadLine() ?? "";

            Console.WriteLine("Chọn loại phòng:");
            Console.WriteLine("  1. Đơn");
            Console.WriteLine("  2. Đôi");
            Console.WriteLine("  3. VIP");
            Console.Write("Lựa chọn: ");
            string loai = Console.ReadLine() ?? "";

            LoaiPhong loaiPhong = loai switch
            {
                "1" => LoaiPhong.Don,
                "2" => LoaiPhong.Doi,
                "3" => LoaiPhong.VIP,
                _ => LoaiPhong.Don
            };

            Console.Write("Nhập giá tiền (VND/đêm): ");
            if (decimal.TryParse(Console.ReadLine(), out decimal giaTien))
            {
                heThong.ThemPhongMoi(maPhong, loaiPhong, giaTien);
            }
            else
            {
                Console.WriteLine("✗ Giá tiền không hợp lệ!");
            }

            PressAnyKey();
        }

        /// <summary>
        /// Sửa thông tin phòng
        /// </summary>
        private void SuaPhong()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║           SỬA THÔNG TIN PHÒNG                    ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.Write("Nhập mã phòng cần sửa: ");
            string maPhong = Console.ReadLine() ?? "";

            Console.Write("Nhập giá tiền mới (VND/đêm, bỏ trống nếu không đổi): ");
            string giaTienStr = Console.ReadLine() ?? "";

            decimal? giaTienMoi = null;
            if (!string.IsNullOrEmpty(giaTienStr) && decimal.TryParse(giaTienStr, out decimal giaTien))
            {
                giaTienMoi = giaTien;
            }

            heThong.SuaPhongTin(maPhong, null, giaTienMoi);
            PressAnyKey();
        }

        /// <summary>
        /// Xóa phòng
        /// </summary>
        private void XoaPhong()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║              XÓA PHÒNG                            ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.Write("Nhập mã phòng cần xóa: ");
            string maPhong = Console.ReadLine() ?? "";

            heThong.XoaPhongKhiSan(maPhong);
            PressAnyKey();
        }

        /// <summary>
        /// Thêm nhân viên
        /// </summary>
        private void ThemNhanVien()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║            THÊM NHÂN VIÊN MỚI                    ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.Write("Nhập họ tên: ");
            string hoTen = Console.ReadLine() ?? "";

            Console.Write("Nhập số điện thoại: ");
            string sdt = Console.ReadLine() ?? "";

            Console.Write("Nhập mật khẩu (tối thiểu 6 ký tự): ");
            string matKhau = Doc_PasswordKhongHienThi();

            heThong.ThemNhanVienMoi(hoTen, sdt, matKhau);
            PressAnyKey();
        }

        /// <summary>
        /// Xóa nhân viên
        /// </summary>
        private void XoaNhanVien()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║             XÓA NHÂN VIÊN                        ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            heThong.HienThiDanhSachNhanVien();

            Console.Write("\nNhập SĐT nhân viên cần xóa: ");
            string sdt = Console.ReadLine() ?? "";

            heThong.XoaNhanVien(sdt);
            PressAnyKey();
        }

        /// <summary>
        /// Xem báo cáo doanh thu
        /// </summary>
        private void XemBaoCaoDoanhThu()
        {
            Console.Clear();
            Console.WriteLine("╔═══════════════════════════════════════════════════╗");
            Console.WriteLine("║           BÁO CÁO DOANH THU                      ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════╝\n");

            Console.Write("Nhập tháng (1-12): ");
            if (int.TryParse(Console.ReadLine(), out int thang) && thang >= 1 && thang <= 12)
            {
                Console.Write("Nhập năm (ví dụ: 2024): ");
                if (int.TryParse(Console.ReadLine(), out int nam) && nam > 0)
                {
                    heThong.XemBaoCaoDoanhThu(thang, nam);
                }
                else
                {
                    Console.WriteLine("✗ Năm không hợp lệ!");
                }
            }
            else
            {
                Console.WriteLine("✗ Tháng không hợp lệ!");
            }

            PressAnyKey();
        }

        /// <summary>
        /// Hỗ trợ các phương thức chung
        /// </summary>
        private void PressAnyKey()
        {
            Console.WriteLine("\n>>> Nhấn bất kỳ phím nào để tiếp tục...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Đọc mật khẩu không hiển thị
        /// </summary>
        private string Doc_PasswordKhongHienThi()
        {
            string password = "";
            ConsoleKey key;

            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;

                if (key == ConsoleKey.Backspace)
                {
                    if (password.Length > 0)
                    {
                        password = password.Substring(0, password.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else if (key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (char.IsAscii((char)keyInfo.KeyChar))
                {
                    password += keyInfo.KeyChar;
                    Console.Write("*");
                }
            } while (key != ConsoleKey.Enter);

            Console.WriteLine();
            return password;
        }
    }
}
